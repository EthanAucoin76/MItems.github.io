// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.gui;

import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraft.client.gui.widget.Widget;
import net.minecraft.client.gui.widget.button.Button;
import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.GL11;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.ResourceLocation;
import net.minecraft.client.gui.screen.inventory.ContainerScreen;
import ethanacoin76.mcreator.mod.ModMod;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.entity.Entity;
import net.minecraft.inventory.IInventory;
import net.minecraft.item.ItemStack;
import net.minecraftforge.items.SlotItemHandler;
import net.minecraft.util.Direction;
import net.minecraftforge.items.CapabilityItemHandler;
import net.minecraftforge.items.ItemStackHandler;
import net.minecraftforge.items.IItemHandler;
import net.minecraft.inventory.container.Slot;
import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.inventory.container.Container;
import net.minecraft.network.PacketBuffer;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraftforge.fml.network.IContainerFactory;
import net.minecraft.world.World;
import net.minecraft.util.math.BlockPos;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.DeferredWorkQueue;
import net.minecraft.client.gui.ScreenManager;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.inventory.container.ContainerType;
import java.util.HashMap;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppercrafterGui extends ModModElements.ModElement
{
    public static HashMap guistate;
    private static ContainerType<GuiContainerMod> containerType;
    
    public CoppercrafterGui(final ModModElements instance) {
        super(instance, 25);
        this.elements.addNetworkMessage(ButtonPressedMessage.class, ButtonPressedMessage::buffer, ButtonPressedMessage::new, ButtonPressedMessage::handler);
        this.elements.addNetworkMessage(GUISlotChangedMessage.class, GUISlotChangedMessage::buffer, GUISlotChangedMessage::new, GUISlotChangedMessage::handler);
        CoppercrafterGui.containerType = (ContainerType<GuiContainerMod>)new ContainerType((ContainerType.IFactory)new GuiContainerModFactory());
        FMLJavaModLoadingContext.get().getModEventBus().register((Object)this);
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void initElements() {
        DeferredWorkQueue.runLater(() -> ScreenManager.func_216911_a((ContainerType)CoppercrafterGui.containerType, GuiWindow::new));
    }
    
    @SubscribeEvent
    public void registerContainer(final RegistryEvent.Register<ContainerType<?>> event) {
        event.getRegistry().register(CoppercrafterGui.containerType.setRegistryName("coppercrafter"));
    }
    
    private static void handleButtonAction(final PlayerEntity entity, final int buttonID, final int x, final int y, final int z) {
        final World world = entity.field_70170_p;
        if (!world.func_175667_e(new BlockPos(x, y, z))) {
            return;
        }
    }
    
    private static void handleSlotAction(final PlayerEntity entity, final int slotID, final int changeType, final int meta, final int x, final int y, final int z) {
        final World world = entity.field_70170_p;
        if (!world.func_175667_e(new BlockPos(x, y, z))) {
            return;
        }
    }
    
    static {
        CoppercrafterGui.guistate = new HashMap();
        CoppercrafterGui.containerType = null;
    }
    
    public static class GuiContainerModFactory implements IContainerFactory
    {
        public GuiContainerMod create(final int id, final PlayerInventory inv, final PacketBuffer extraData) {
            return new GuiContainerMod(id, inv, extraData);
        }
    }
    
    public static class GuiContainerMod extends Container implements Supplier<Map<Integer, Slot>>
    {
        private World world;
        private PlayerEntity entity;
        private int x;
        private int y;
        private int z;
        private IItemHandler internal;
        private Map<Integer, Slot> customSlots;
        private boolean bound;
        
        public GuiContainerMod(final int id, final PlayerInventory inv, final PacketBuffer extraData) {
            super(CoppercrafterGui.containerType, id);
            this.customSlots = new HashMap<Integer, Slot>();
            this.bound = false;
            this.entity = inv.field_70458_d;
            this.world = inv.field_70458_d.field_70170_p;
            this.internal = (IItemHandler)new ItemStackHandler(21);
            BlockPos pos = null;
            if (extraData != null) {
                pos = extraData.func_179259_c();
                this.x = pos.func_177958_n();
                this.y = pos.func_177956_o();
                this.z = pos.func_177952_p();
            }
            if (pos != null) {
                if (extraData.readableBytes() == 1) {
                    final byte hand = extraData.readByte();
                    ItemStack itemstack;
                    if (hand == 0) {
                        itemstack = this.entity.func_184614_ca();
                    }
                    else {
                        itemstack = this.entity.func_184592_cb();
                    }
                    itemstack.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, (Direction)null).ifPresent(capability -> {
                        this.internal = capability;
                        this.bound = true;
                    });
                }
                else if (extraData.readableBytes() > 1) {
                    extraData.readByte();
                    final Entity entity = this.world.func_73045_a(extraData.func_150792_a());
                    if (entity != null) {
                        entity.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, (Direction)null).ifPresent(capability -> {
                            this.internal = capability;
                            this.bound = true;
                        });
                    }
                }
                else {
                    final TileEntity ent = (inv.field_70458_d != null) ? inv.field_70458_d.field_70170_p.func_175625_s(pos) : null;
                    if (ent != null) {
                        ent.getCapability(CapabilityItemHandler.ITEM_HANDLER_CAPABILITY, (Direction)null).ifPresent(capability -> {
                            this.internal = capability;
                            this.bound = true;
                        });
                    }
                }
            }
            this.customSlots.put(11, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 11, 138, 37) {
                public boolean func_75214_a(final ItemStack stack) {
                    return false;
                }
            }));
            this.customSlots.put(12, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 12, 11, 21) {}));
            this.customSlots.put(13, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 13, 28, 21) {}));
            this.customSlots.put(14, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 14, 45, 21) {}));
            this.customSlots.put(15, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 15, 26, 37) {}));
            this.customSlots.put(16, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 16, 45, 38) {}));
            this.customSlots.put(17, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 17, 5, 36) {}));
            this.customSlots.put(18, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 18, 46, 55) {}));
            this.customSlots.put(19, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 19, 26, 54) {}));
            this.customSlots.put(20, this.func_75146_a((Slot)new SlotItemHandler(this.internal, 20, 6, 54) {}));
            for (int si = 0; si < 3; ++si) {
                for (int sj = 0; sj < 9; ++sj) {
                    this.func_75146_a(new Slot((IInventory)inv, sj + (si + 1) * 9, 8 + sj * 18, 84 + si * 18));
                }
            }
            for (int si = 0; si < 9; ++si) {
                this.func_75146_a(new Slot((IInventory)inv, si, 8 + si * 18, 142));
            }
        }
        
        public Map<Integer, Slot> get() {
            return this.customSlots;
        }
        
        public boolean func_75145_c(final PlayerEntity player) {
            return true;
        }
        
        public ItemStack func_82846_b(final PlayerEntity playerIn, final int index) {
            ItemStack itemstack = ItemStack.field_190927_a;
            final Slot slot = this.field_75151_b.get(index);
            if (slot != null && slot.func_75216_d()) {
                final ItemStack itemstack2 = slot.func_75211_c();
                itemstack = itemstack2.func_77946_l();
                if (index < 10) {
                    if (!this.func_75135_a(itemstack2, 10, this.field_75151_b.size(), true)) {
                        return ItemStack.field_190927_a;
                    }
                    slot.func_75220_a(itemstack2, itemstack);
                }
                else if (!this.func_75135_a(itemstack2, 0, 10, false)) {
                    if (index < 37) {
                        if (!this.func_75135_a(itemstack2, 37, this.field_75151_b.size(), true)) {
                            return ItemStack.field_190927_a;
                        }
                    }
                    else if (!this.func_75135_a(itemstack2, 10, 37, false)) {
                        return ItemStack.field_190927_a;
                    }
                    return ItemStack.field_190927_a;
                }
                if (itemstack2.func_190916_E() == 0) {
                    slot.func_75215_d(ItemStack.field_190927_a);
                }
                else {
                    slot.func_75218_e();
                }
                if (itemstack2.func_190916_E() == itemstack.func_190916_E()) {
                    return ItemStack.field_190927_a;
                }
                slot.func_190901_a(playerIn, itemstack2);
            }
            return itemstack;
        }
        
        protected boolean func_75135_a(final ItemStack stack, final int startIndex, final int endIndex, final boolean reverseDirection) {
            boolean flag = false;
            int i = startIndex;
            if (reverseDirection) {
                i = endIndex - 1;
            }
            if (stack.func_77985_e()) {
                while (!stack.func_190926_b()) {
                    if (reverseDirection) {
                        if (i < startIndex) {
                            break;
                        }
                    }
                    else if (i >= endIndex) {
                        break;
                    }
                    final Slot slot = this.field_75151_b.get(i);
                    final ItemStack itemstack = slot.func_75211_c();
                    if (slot.func_75214_a(itemstack) && !itemstack.func_190926_b() && func_195929_a(stack, itemstack)) {
                        final int j = itemstack.func_190916_E() + stack.func_190916_E();
                        final int maxSize = Math.min(slot.func_75219_a(), stack.func_77976_d());
                        if (j <= maxSize) {
                            stack.func_190920_e(0);
                            itemstack.func_190920_e(j);
                            slot.func_75215_d(itemstack);
                            flag = true;
                        }
                        else if (itemstack.func_190916_E() < maxSize) {
                            stack.func_190918_g(maxSize - itemstack.func_190916_E());
                            itemstack.func_190920_e(maxSize);
                            slot.func_75215_d(itemstack);
                            flag = true;
                        }
                    }
                    if (reverseDirection) {
                        --i;
                    }
                    else {
                        ++i;
                    }
                }
            }
            if (!stack.func_190926_b()) {
                if (reverseDirection) {
                    i = endIndex - 1;
                }
                else {
                    i = startIndex;
                }
                while (true) {
                    if (reverseDirection) {
                        if (i < startIndex) {
                            break;
                        }
                    }
                    else if (i >= endIndex) {
                        break;
                    }
                    final Slot slot2 = this.field_75151_b.get(i);
                    final ItemStack itemstack2 = slot2.func_75211_c();
                    if (itemstack2.func_190926_b() && slot2.func_75214_a(stack)) {
                        if (stack.func_190916_E() > slot2.func_75219_a()) {
                            slot2.func_75215_d(stack.func_77979_a(slot2.func_75219_a()));
                        }
                        else {
                            slot2.func_75215_d(stack.func_77979_a(stack.func_190916_E()));
                        }
                        slot2.func_75218_e();
                        flag = true;
                        break;
                    }
                    if (reverseDirection) {
                        --i;
                    }
                    else {
                        ++i;
                    }
                }
            }
            return flag;
        }
        
        public void func_75134_a(final PlayerEntity playerIn) {
            super.func_75134_a(playerIn);
            if (!this.bound && playerIn instanceof ServerPlayerEntity) {
                if (!playerIn.func_70089_S() || (playerIn instanceof ServerPlayerEntity && ((ServerPlayerEntity)playerIn).func_193105_t())) {
                    for (int j = 0; j < this.internal.getSlots(); ++j) {
                        playerIn.func_71019_a(this.internal.extractItem(j, this.internal.getStackInSlot(j).func_190916_E(), false), false);
                    }
                }
                else {
                    for (int i = 0; i < this.internal.getSlots(); ++i) {
                        playerIn.field_71071_by.func_191975_a(playerIn.field_70170_p, this.internal.extractItem(i, this.internal.getStackInSlot(i).func_190916_E(), false));
                    }
                }
            }
        }
        
        private void slotChanged(final int slotid, final int ctype, final int meta) {
            if (this.world != null && this.world.field_72995_K) {
                ModMod.PACKET_HANDLER.sendToServer((Object)new GUISlotChangedMessage(slotid, this.x, this.y, this.z, ctype, meta));
                handleSlotAction(this.entity, slotid, ctype, meta, this.x, this.y, this.z);
            }
        }
    }
    
    @OnlyIn(Dist.CLIENT)
    public static class GuiWindow extends ContainerScreen<GuiContainerMod>
    {
        private World world;
        private int x;
        private int y;
        private int z;
        private PlayerEntity entity;
        private static final ResourceLocation texture;
        
        public GuiWindow(final GuiContainerMod container, final PlayerInventory inventory, final ITextComponent text) {
            super((Container)container, inventory, text);
            this.world = container.world;
            this.x = container.x;
            this.y = container.y;
            this.z = container.z;
            this.entity = container.entity;
            this.field_146999_f = 176;
            this.field_147000_g = 166;
        }
        
        public void render(final int mouseX, final int mouseY, final float partialTicks) {
            this.renderBackground();
            super.render(mouseX, mouseY, partialTicks);
            this.func_191948_b(mouseX, mouseY);
        }
        
        protected void func_146976_a(final float par1, final int par2, final int par3) {
            GL11.glColor4f(1.0f, 1.0f, 1.0f, 1.0f);
            Minecraft.func_71410_x().func_110434_K().func_110577_a(GuiWindow.texture);
            final int k = (this.width - this.field_146999_f) / 2;
            final int l = (this.height - this.field_147000_g) / 2;
            blit(k, l, 0.0f, 0.0f, this.field_146999_f, this.field_147000_g, this.field_146999_f, this.field_147000_g);
        }
        
        public boolean keyPressed(final int key, final int b, final int c) {
            if (key == 256) {
                this.minecraft.field_71439_g.func_71053_j();
                return true;
            }
            return super.keyPressed(key, b, c);
        }
        
        public void tick() {
            super.tick();
        }
        
        protected void func_146979_b(final int mouseX, final int mouseY) {
            this.font.func_211126_b("craft yo copper", 11.0f, 8.0f, -12829636);
            this.font.func_211126_b("inventory", 6.0f, 71.0f, -12829636);
        }
        
        public void removed() {
            super.removed();
            Minecraft.func_71410_x().field_195559_v.func_197967_a(false);
        }
        
        public void init(final Minecraft minecraft, final int width, final int height) {
            super.init(minecraft, width, height);
            minecraft.field_195559_v.func_197967_a(true);
            this.addButton((Widget)new Button(this.field_147003_i + 76, this.field_147009_r + 35, 50, 20, "craft", e -> {
                ModMod.PACKET_HANDLER.sendToServer((Object)new ButtonPressedMessage(0, this.x, this.y, this.z));
                handleButtonAction(this.entity, 0, this.x, this.y, this.z);
            }));
        }
        
        static {
            texture = new ResourceLocation("mod:textures/coppercrafter.png");
        }
    }
    
    public static class ButtonPressedMessage
    {
        int buttonID;
        int x;
        int y;
        int z;
        
        public ButtonPressedMessage(final PacketBuffer buffer) {
            this.buttonID = buffer.readInt();
            this.x = buffer.readInt();
            this.y = buffer.readInt();
            this.z = buffer.readInt();
        }
        
        public ButtonPressedMessage(final int buttonID, final int x, final int y, final int z) {
            this.buttonID = buttonID;
            this.x = x;
            this.y = y;
            this.z = z;
        }
        
        public static void buffer(final ButtonPressedMessage message, final PacketBuffer buffer) {
            buffer.writeInt(message.buttonID);
            buffer.writeInt(message.x);
            buffer.writeInt(message.y);
            buffer.writeInt(message.z);
        }
        
        public static void handler(final ButtonPressedMessage message, final Supplier<NetworkEvent.Context> contextSupplier) {
            final NetworkEvent.Context context = contextSupplier.get();
            final PlayerEntity entity;
            final int buttonID;
            final int x;
            final int y;
            final int z;
            context.enqueueWork(() -> {
                entity = (PlayerEntity)context.getSender();
                buttonID = message.buttonID;
                x = message.x;
                y = message.y;
                z = message.z;
                handleButtonAction(entity, buttonID, x, y, z);
                return;
            });
            context.setPacketHandled(true);
        }
    }
    
    public static class GUISlotChangedMessage
    {
        int slotID;
        int x;
        int y;
        int z;
        int changeType;
        int meta;
        
        public GUISlotChangedMessage(final int slotID, final int x, final int y, final int z, final int changeType, final int meta) {
            this.slotID = slotID;
            this.x = x;
            this.y = y;
            this.z = z;
            this.changeType = changeType;
            this.meta = meta;
        }
        
        public GUISlotChangedMessage(final PacketBuffer buffer) {
            this.slotID = buffer.readInt();
            this.x = buffer.readInt();
            this.y = buffer.readInt();
            this.z = buffer.readInt();
            this.changeType = buffer.readInt();
            this.meta = buffer.readInt();
        }
        
        public static void buffer(final GUISlotChangedMessage message, final PacketBuffer buffer) {
            buffer.writeInt(message.slotID);
            buffer.writeInt(message.x);
            buffer.writeInt(message.y);
            buffer.writeInt(message.z);
            buffer.writeInt(message.changeType);
            buffer.writeInt(message.meta);
        }
        
        public static void handler(final GUISlotChangedMessage message, final Supplier<NetworkEvent.Context> contextSupplier) {
            final NetworkEvent.Context context = contextSupplier.get();
            final PlayerEntity entity;
            final int slotID;
            final int changeType;
            final int meta;
            final int x;
            final int y;
            final int z;
            context.enqueueWork(() -> {
                entity = (PlayerEntity)context.getSender();
                slotID = message.slotID;
                changeType = message.changeType;
                meta = message.meta;
                x = message.x;
                y = message.y;
                z = message.z;
                handleSlotAction(entity, slotID, changeType, meta, x, y, z);
                return;
            });
            context.setPacketHandled(true);
        }
    }
}
