// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod;

import net.minecraftforge.fml.network.NetworkEvent;
import net.minecraft.network.PacketBuffer;
import net.minecraft.world.dimension.DimensionType;
import net.minecraft.world.server.ServerWorld;
import java.util.function.Supplier;
import net.minecraft.nbt.INBT;
import net.minecraft.nbt.CompoundNBT;
import net.minecraft.item.ItemStack;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraft.world.storage.WorldSavedData;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraftforge.fml.network.PacketDistributor;
import net.minecraft.world.IWorld;
import net.minecraftforge.event.entity.player.PlayerEvent;

public class ModModVariables
{
    public ModModVariables(final ModModElements elements) {
        elements.addNetworkMessage(WorldSavedDataSyncMessage.class, WorldSavedDataSyncMessage::buffer, WorldSavedDataSyncMessage::new, WorldSavedDataSyncMessage::handler);
    }
    
    @SubscribeEvent
    public void onPlayerLoggedIn(final PlayerEvent.PlayerLoggedInEvent event) {
        if (!event.getPlayer().field_70170_p.field_72995_K) {
            final WorldSavedData mapdata = MapVariables.get((IWorld)event.getPlayer().field_70170_p);
            final WorldSavedData worlddata = WorldVariables.get((IWorld)event.getPlayer().field_70170_p);
            if (mapdata != null) {
                ModMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity)event.getPlayer()), (Object)new WorldSavedDataSyncMessage(0, mapdata));
            }
            if (worlddata != null) {
                ModMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity)event.getPlayer()), (Object)new WorldSavedDataSyncMessage(1, worlddata));
            }
        }
    }
    
    @SubscribeEvent
    public void onPlayerChangedDimension(final PlayerEvent.PlayerChangedDimensionEvent event) {
        if (!event.getPlayer().field_70170_p.field_72995_K) {
            final WorldSavedData worlddata = WorldVariables.get((IWorld)event.getPlayer().field_70170_p);
            if (worlddata != null) {
                ModMod.PACKET_HANDLER.send(PacketDistributor.PLAYER.with(() -> (ServerPlayerEntity)event.getPlayer()), (Object)new WorldSavedDataSyncMessage(1, worlddata));
            }
        }
    }
    
    public static class WorldVariables extends WorldSavedData
    {
        public static final String DATA_NAME = "mod_worldvars";
        public ItemStack if_item_in_hand;
        static WorldVariables clientSide;
        
        public WorldVariables() {
            super("mod_worldvars");
            this.if_item_in_hand = ItemStack.field_190927_a;
        }
        
        public WorldVariables(final String s) {
            super(s);
            this.if_item_in_hand = ItemStack.field_190927_a;
        }
        
        public void func_76184_a(final CompoundNBT nbt) {
            this.if_item_in_hand = ItemStack.func_199557_a(nbt.func_74775_l("if_item_in_hand"));
        }
        
        public CompoundNBT func_189551_b(final CompoundNBT nbt) {
            nbt.func_218657_a("if_item_in_hand", (INBT)this.if_item_in_hand.func_77955_b(new CompoundNBT()));
            return nbt;
        }
        
        public void syncData(final IWorld world) {
            this.func_76185_a();
            if (!world.func_201672_e().field_72995_K) {
                ModMod.PACKET_HANDLER.send(PacketDistributor.DIMENSION.with((Supplier)world.func_201672_e().field_73011_w::func_186058_p), (Object)new WorldSavedDataSyncMessage(1, this));
            }
        }
        
        public static WorldVariables get(final IWorld world) {
            if (world.func_201672_e() instanceof ServerWorld) {
                return (WorldVariables)((ServerWorld)world.func_201672_e()).func_217481_x().func_215752_a((Supplier)WorldVariables::new, "mod_worldvars");
            }
            return WorldVariables.clientSide;
        }
        
        static {
            WorldVariables.clientSide = new WorldVariables();
        }
    }
    
    public static class MapVariables extends WorldSavedData
    {
        public static final String DATA_NAME = "mod_mapvars";
        public String if_coal;
        static MapVariables clientSide;
        
        public MapVariables() {
            super("mod_mapvars");
            this.if_coal = "";
        }
        
        public MapVariables(final String s) {
            super(s);
            this.if_coal = "";
        }
        
        public void func_76184_a(final CompoundNBT nbt) {
            this.if_coal = nbt.func_74779_i("if_coal");
        }
        
        public CompoundNBT func_189551_b(final CompoundNBT nbt) {
            nbt.func_74778_a("if_coal", this.if_coal);
            return nbt;
        }
        
        public void syncData(final IWorld world) {
            this.func_76185_a();
            if (!world.func_201672_e().field_72995_K) {
                ModMod.PACKET_HANDLER.send(PacketDistributor.ALL.noArg(), (Object)new WorldSavedDataSyncMessage(0, this));
            }
        }
        
        public static MapVariables get(final IWorld world) {
            if (world.func_201672_e() instanceof ServerWorld) {
                return (MapVariables)world.func_201672_e().func_73046_m().func_71218_a(DimensionType.field_223227_a_).func_217481_x().func_215752_a((Supplier)MapVariables::new, "mod_mapvars");
            }
            return MapVariables.clientSide;
        }
        
        static {
            MapVariables.clientSide = new MapVariables();
        }
    }
    
    public static class WorldSavedDataSyncMessage
    {
        public int type;
        public WorldSavedData data;
        
        public WorldSavedDataSyncMessage(final PacketBuffer buffer) {
            this.type = buffer.readInt();
            (this.data = ((this.type == 0) ? new MapVariables() : new WorldVariables())).func_76184_a(buffer.func_150793_b());
        }
        
        public WorldSavedDataSyncMessage(final int type, final WorldSavedData data) {
            this.type = type;
            this.data = data;
        }
        
        public static void buffer(final WorldSavedDataSyncMessage message, final PacketBuffer buffer) {
            buffer.writeInt(message.type);
            buffer.func_150786_a(message.data.func_189551_b(new CompoundNBT()));
        }
        
        public static void handler(final WorldSavedDataSyncMessage message, final Supplier<NetworkEvent.Context> contextSupplier) {
            final NetworkEvent.Context context = contextSupplier.get();
            context.enqueueWork(() -> {
                if (!context.getDirection().getReceptionSide().isServer()) {
                    if (message.type == 0) {
                        MapVariables.clientSide = (MapVariables)message.data;
                    }
                    else {
                        WorldVariables.clientSide = (WorldVariables)message.data;
                    }
                }
                return;
            });
            context.setPacketHandled(true);
        }
    }
}
