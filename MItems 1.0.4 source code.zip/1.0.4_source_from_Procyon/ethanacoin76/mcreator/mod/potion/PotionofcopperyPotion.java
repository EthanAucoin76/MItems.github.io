// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.potion;

import ethanacoin76.mcreator.mod.procedures.PotionofcopperyPotionExpiresProcedure;
import net.minecraft.entity.ai.attributes.AbstractAttributeMap;
import java.util.Map;
import net.minecraft.world.World;
import ethanacoin76.mcreator.mod.procedures.PotionofcopperyPotionStartedappliedProcedure;
import java.util.HashMap;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import net.minecraft.potion.EffectType;
import net.minecraft.util.ResourceLocation;
import net.minecraft.potion.EffectInstance;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.registries.IForgeRegistryEntry;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraft.potion.Potion;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.potion.Effect;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class PotionofcopperyPotion extends ModModElements.ModElement
{
    @ObjectHolder("mod:potionofcoppery")
    public static final Effect potion;
    @ObjectHolder("mod:potionofcoppery")
    public static final Potion potionType;
    
    public PotionofcopperyPotion(final ModModElements instance) {
        super(instance, 57);
        FMLJavaModLoadingContext.get().getModEventBus().register((Object)this);
    }
    
    @SubscribeEvent
    public void registerEffect(final RegistryEvent.Register<Effect> event) {
        event.getRegistry().register((IForgeRegistryEntry)new EffectCustom());
    }
    
    @SubscribeEvent
    public void registerPotion(final RegistryEvent.Register<Potion> event) {
        event.getRegistry().register((IForgeRegistryEntry)new PotionCustom());
    }
    
    static {
        potion = null;
        potionType = null;
    }
    
    public static class PotionCustom extends Potion
    {
        public PotionCustom() {
            super(new EffectInstance[] { new EffectInstance(PotionofcopperyPotion.potion, 3600) });
            this.setRegistryName("potionofcoppery");
        }
    }
    
    public static class EffectCustom extends Effect
    {
        private final ResourceLocation potionIcon;
        
        public EffectCustom() {
            super(EffectType.NEUTRAL, -26368);
            this.setRegistryName("potionofcoppery");
            this.potionIcon = new ResourceLocation("mod:textures/copperingot.png");
        }
        
        public String func_76393_a() {
            return "effect.potionofcoppery";
        }
        
        public boolean func_188408_i() {
            return false;
        }
        
        public boolean func_76403_b() {
            return true;
        }
        
        public boolean shouldRenderInvText(final EffectInstance effect) {
            return true;
        }
        
        public boolean shouldRender(final EffectInstance effect) {
            return true;
        }
        
        public boolean shouldRenderHUD(final EffectInstance effect) {
            return true;
        }
        
        public void func_180793_a(final Entity source, final Entity indirectSource, final LivingEntity entity, final int amplifier, final double health) {
            final World world = entity.field_70170_p;
            final double x = entity.func_226277_ct_();
            final double y = entity.func_226278_cu_();
            final double z = entity.func_226281_cx_();
            final Map<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("x", x);
            $_dependencies.put("y", y);
            $_dependencies.put("z", z);
            $_dependencies.put("world", world);
            PotionofcopperyPotionStartedappliedProcedure.executeProcedure($_dependencies);
        }
        
        public void func_111187_a(final LivingEntity entity, final AbstractAttributeMap attributeMapIn, final int amplifier) {
            super.func_111187_a(entity, attributeMapIn, amplifier);
            final World world = entity.field_70170_p;
            final double x = entity.func_226277_ct_();
            final double y = entity.func_226278_cu_();
            final double z = entity.func_226281_cx_();
            final Map<String, Object> $_dependencies = new HashMap<String, Object>();
            $_dependencies.put("entity", entity);
            PotionofcopperyPotionExpiresProcedure.executeProcedure($_dependencies);
        }
        
        public boolean func_76397_a(final int duration, final int amplifier) {
            return true;
        }
    }
}
