// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.block;

import java.util.Collections;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.shapes.VoxelShapes;
import net.minecraft.util.math.shapes.VoxelShape;
import net.minecraft.util.math.shapes.ISelectionContext;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.block.BlockState;
import net.minecraftforge.common.ToolType;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.client.renderer.RenderTypeLookup;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.block.Block;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperoreBlock extends ModModElements.ModElement
{
    @ObjectHolder("mod:copperore")
    public static final Block block;
    
    public CopperoreBlock(final ModModElements instance) {
        super(instance, 16);
    }
    
    @Override
    public void initElements() {
        this.elements.blocks.add(() -> new CustomBlock());
        final BlockItem blockItem;
        this.elements.items.add(() -> {
            new BlockItem(CopperoreBlock.block, new Item.Properties().func_200916_a(MitemsItemGroup.tab));
            return (Item)blockItem.setRegistryName(CopperoreBlock.block.getRegistryName());
        });
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void clientLoad(final FMLClientSetupEvent event) {
        RenderTypeLookup.setRenderLayer(CopperoreBlock.block, RenderType.func_228643_e_());
    }
    
    static {
        block = null;
    }
    
    public static class CustomBlock extends Block
    {
        public CustomBlock() {
            super(Block.Properties.func_200945_a(Material.field_151576_e).func_200947_a(SoundType.field_185851_d).func_200948_a(1.0f, 10.0f).func_200951_a(0).harvestLevel(1).harvestTool(ToolType.PICKAXE).func_226896_b_());
            this.setRegistryName("copperore");
        }
        
        public boolean func_220081_d(final BlockState state, final IBlockReader worldIn, final BlockPos pos) {
            return false;
        }
        
        public VoxelShape func_220053_a(final BlockState state, final IBlockReader world, final BlockPos pos, final ISelectionContext context) {
            final Vec3d offset = state.func_191059_e(world, pos);
            return VoxelShapes.func_197873_a(0.0, 0.0, 0.0, 1.0, 5.0, 1.0).func_197751_a(offset.field_72450_a, offset.field_72448_b, offset.field_72449_c);
        }
        
        public List<ItemStack> func_220076_a(final BlockState state, final LootContext.Builder builder) {
            final List<ItemStack> dropsOriginal = (List<ItemStack>)super.func_220076_a(state, builder);
            if (!dropsOriginal.isEmpty()) {
                return dropsOriginal;
            }
            return Collections.singletonList(new ItemStack((IItemProvider)this, 1));
        }
    }
}
