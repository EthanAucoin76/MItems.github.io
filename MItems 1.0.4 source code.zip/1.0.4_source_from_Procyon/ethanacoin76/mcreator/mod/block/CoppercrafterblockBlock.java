// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.block;

import net.minecraftforge.fml.network.NetworkHooks;
import ethanacoin76.mcreator.mod.gui.CoppercrafterGui;
import net.minecraft.network.PacketBuffer;
import io.netty.buffer.Unpooled;
import net.minecraft.inventory.container.Container;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.util.text.StringTextComponent;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.inventory.container.INamedContainerProvider;
import net.minecraft.entity.player.ServerPlayerEntity;
import net.minecraft.util.ActionResultType;
import net.minecraft.util.math.BlockRayTraceResult;
import net.minecraft.util.Hand;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.world.World;
import java.util.Collections;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import java.util.List;
import net.minecraft.world.storage.loot.LootContext;
import net.minecraft.pathfinding.PathNodeType;
import net.minecraft.entity.MobEntity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.IBlockReader;
import net.minecraft.block.BlockState;
import net.minecraft.world.IWorldReader;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.item.Item;
import net.minecraft.item.BlockItem;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.block.Block;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppercrafterblockBlock extends ModModElements.ModElement
{
    @ObjectHolder("mod:coppercrafterblock")
    public static final Block block;
    
    public CoppercrafterblockBlock(final ModModElements instance) {
        super(instance, 26);
    }
    
    @Override
    public void initElements() {
        this.elements.blocks.add(() -> new CustomBlock());
        final BlockItem blockItem;
        this.elements.items.add(() -> {
            new BlockItem(CoppercrafterblockBlock.block, new Item.Properties().func_200916_a(MitemsItemGroup.tab));
            return (Item)blockItem.setRegistryName(CoppercrafterblockBlock.block.getRegistryName());
        });
    }
    
    static {
        block = null;
    }
    
    public static class CustomBlock extends Block
    {
        public CustomBlock() {
            super(Block.Properties.func_200945_a(Material.field_151575_d).func_200947_a(SoundType.field_185848_a).func_200948_a(1.0f, 10.0f).func_200951_a(0));
            this.setRegistryName("coppercrafterblock");
        }
        
        public int func_149738_a(final IWorldReader world) {
            return 1;
        }
        
        public PathNodeType getAiPathNodeType(final BlockState state, final IBlockReader world, final BlockPos pos, final MobEntity entity) {
            return PathNodeType.BLOCKED;
        }
        
        public List<ItemStack> func_220076_a(final BlockState state, final LootContext.Builder builder) {
            final List<ItemStack> dropsOriginal = (List<ItemStack>)super.func_220076_a(state, builder);
            if (!dropsOriginal.isEmpty()) {
                return dropsOriginal;
            }
            return Collections.singletonList(new ItemStack((IItemProvider)this, 1));
        }
        
        public ActionResultType func_225533_a_(final BlockState state, final World world, final BlockPos pos, final PlayerEntity entity, final Hand hand, final BlockRayTraceResult hit) {
            super.func_225533_a_(state, world, pos, entity, hand, hit);
            final int x = pos.func_177958_n();
            final int y = pos.func_177956_o();
            final int z = pos.func_177952_p();
            if (entity instanceof ServerPlayerEntity) {
                NetworkHooks.openGui((ServerPlayerEntity)entity, (INamedContainerProvider)new INamedContainerProvider() {
                    public ITextComponent func_145748_c_() {
                        return (ITextComponent)new StringTextComponent("Coppercrafterblock");
                    }
                    
                    public Container createMenu(final int id, final PlayerInventory inventory, final PlayerEntity player) {
                        return new CoppercrafterGui.GuiContainerMod(id, inventory, new PacketBuffer(Unpooled.buffer()).func_179255_a(new BlockPos(x, y, z)));
                    }
                }, new BlockPos(x, y, z));
            }
            return ActionResultType.SUCCESS;
        }
    }
}
