// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.command;

import java.util.Map;
import net.minecraft.entity.Entity;
import net.minecraft.world.server.ServerWorld;
import ethanacoin76.mcreator.mod.procedures.CoppergiveCommandExecutedProcedure;
import java.util.Arrays;
import java.util.HashMap;
import net.minecraftforge.common.util.FakePlayerFactory;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.arguments.ArgumentType;
import net.minecraft.command.Commands;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.minecraft.command.CommandSource;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppergiveCommand extends ModModElements.ModElement
{
    public CoppergiveCommand(final ModModElements instance) {
        super(instance, 28);
    }
    
    @Override
    public void serverLoad(final FMLServerStartingEvent event) {
        event.getCommandDispatcher().register((LiteralArgumentBuilder)this.customCommand());
    }
    
    private LiteralArgumentBuilder<CommandSource> customCommand() {
        return (LiteralArgumentBuilder<CommandSource>)((LiteralArgumentBuilder)((LiteralArgumentBuilder)LiteralArgumentBuilder.literal("freediamonds").requires(s -> s.func_197034_c(2))).then(Commands.func_197056_a("arguments", (ArgumentType)StringArgumentType.greedyString()).executes(this::execute))).executes(this::execute);
    }
    
    private int execute(final CommandContext<CommandSource> ctx) {
        final ServerWorld world = ((CommandSource)ctx.getSource()).func_197023_e();
        final double x = ((CommandSource)ctx.getSource()).func_197036_d().func_82615_a();
        final double y = ((CommandSource)ctx.getSource()).func_197036_d().func_82617_b();
        final double z = ((CommandSource)ctx.getSource()).func_197036_d().func_82616_c();
        Entity entity = ((CommandSource)ctx.getSource()).func_197022_f();
        if (entity == null) {
            entity = (Entity)FakePlayerFactory.getMinecraft(world);
        }
        final HashMap<String, String> cmdparams = new HashMap<String, String>();
        final int[] index = { -1 };
        final Object o;
        final HashMap<String, String> hashMap;
        final int n;
        Arrays.stream(ctx.getInput().split("\\s+")).forEach(param -> {
            if (o[0] >= 0) {
                hashMap.put(Integer.toString(o[0]), param);
            }
            ++o[n];
            return;
        });
        final Map<String, Object> $_dependencies = new HashMap<String, Object>();
        $_dependencies.put("x", x);
        $_dependencies.put("y", y);
        $_dependencies.put("z", z);
        $_dependencies.put("world", world);
        CoppergiveCommandExecutedProcedure.executeProcedure($_dependencies);
        return 0;
    }
}
