// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.itemgroup;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.util.IItemProvider;
import ethanacoin76.mcreator.mod.item.CopperingotItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class MitemsItemGroup extends ModModElements.ModElement
{
    public static ItemGroup tab;
    
    public MitemsItemGroup(final ModModElements instance) {
        super(instance, 7);
    }
    
    @Override
    public void initElements() {
        MitemsItemGroup.tab = new ItemGroup("tabmitems") {
            @OnlyIn(Dist.CLIENT)
            public ItemStack func_78016_d() {
                return new ItemStack((IItemProvider)CopperingotItem.block, 1);
            }
            
            @OnlyIn(Dist.CLIENT)
            public boolean hasSearchBar() {
                return true;
            }
        }.func_78025_a("item_search.png");
    }
}
