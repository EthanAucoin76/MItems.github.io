// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.itemgroup;

import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.util.IItemProvider;
import ethanacoin76.mcreator.mod.item.OverpoweredshardItem;
import net.minecraft.item.ItemStack;
import net.minecraft.item.ItemGroup;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class MItemsmiscItemGroup extends ModModElements.ModElement
{
    public static ItemGroup tab;
    
    public MItemsmiscItemGroup(final ModModElements instance) {
        super(instance, 44);
    }
    
    @Override
    public void initElements() {
        MItemsmiscItemGroup.tab = new ItemGroup("tabm_itemsmisc") {
            @OnlyIn(Dist.CLIENT)
            public ItemStack func_78016_d() {
                return new ItemStack((IItemProvider)OverpoweredshardItem.block, 1);
            }
            
            @OnlyIn(Dist.CLIENT)
            public boolean hasSearchBar() {
                return false;
            }
        };
    }
}
