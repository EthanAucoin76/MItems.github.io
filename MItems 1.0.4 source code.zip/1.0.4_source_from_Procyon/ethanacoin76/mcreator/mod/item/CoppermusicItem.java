// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.item.Rarity;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraft.util.SoundEvent;
import net.minecraft.item.MusicDiscItem;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppermusicItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:coppermusic")
    public static final Item block;
    
    public CoppermusicItem(final ModModElements instance) {
        super(instance, 37);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new MusicDiscItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class MusicDiscItemCustom extends MusicDiscItem
    {
        public MusicDiscItemCustom() {
            super(0, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("entity.bee.loop")), new Item.Properties().func_200916_a(MitemsItemGroup.tab).func_200917_a(1).func_208103_a(Rarity.RARE));
            this.setRegistryName("coppermusic");
        }
    }
}
