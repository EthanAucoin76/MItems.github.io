// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.util.text.StringTextComponent;
import net.minecraft.client.util.ITooltipFlag;
import net.minecraft.util.text.ITextComponent;
import java.util.List;
import net.minecraft.world.World;
import net.minecraft.item.SwordItem;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.IItemTier;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperswordItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:coppersword")
    public static final Item block;
    
    public CopperswordItem(final ModModElements instance) {
        super(instance, 19);
    }
    
    @Override
    public void initElements() {
        final SwordItem swordItem;
        this.elements.items.add(() -> {
            new SwordItem(new IItemTier() {
                public int func_200926_a() {
                    return 100;
                }
                
                public float func_200928_b() {
                    return 4.0f;
                }
                
                public float func_200929_c() {
                    return 98.0f;
                }
                
                public int func_200925_d() {
                    return 10;
                }
                
                public int func_200927_e() {
                    return 100;
                }
                
                public Ingredient func_200924_f() {
                    return Ingredient.func_193369_a(new ItemStack[] { new ItemStack((IItemProvider)CopperingotItem.block, 1) });
                }
            }, 3, 96.0f, new Item.Properties().func_200916_a(MitemsItemGroup.tab)) {
                public void func_77624_a(final ItemStack itemstack, final World world, final List<ITextComponent> list, final ITooltipFlag flag) {
                    super.func_77624_a(itemstack, world, (List)list, flag);
                    list.add((ITextComponent)new StringTextComponent("copper sword"));
                }
            };
            return (Item)swordItem.setRegistryName("coppersword");
        });
    }
    
    static {
        block = null;
    }
}
