// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.item.ShovelItem;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.IItemTier;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppershovelItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:coppershovel")
    public static final Item block;
    
    public CoppershovelItem(final ModModElements instance) {
        super(instance, 33);
    }
    
    @Override
    public void initElements() {
        final ShovelItem shovelItem;
        this.elements.items.add(() -> {
            new ShovelItem(new IItemTier() {
                public int func_200926_a() {
                    return 100;
                }
                
                public float func_200928_b() {
                    return 10.0f;
                }
                
                public float func_200929_c() {
                    return 2.0f;
                }
                
                public int func_200925_d() {
                    return 1;
                }
                
                public int func_200927_e() {
                    return 10;
                }
                
                public Ingredient func_200924_f() {
                    return Ingredient.field_193370_a;
                }
            }, 1.0f, -3.0f, new Item.Properties().func_200916_a(MitemsItemGroup.tab)) {};
            return (Item)shovelItem.setRegistryName("coppershovel");
        });
    }
    
    static {
        block = null;
    }
}
