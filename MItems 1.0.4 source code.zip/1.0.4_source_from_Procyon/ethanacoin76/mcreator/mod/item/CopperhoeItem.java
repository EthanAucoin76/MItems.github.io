// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;
import net.minecraft.entity.LivingEntity;
import net.minecraft.item.ItemStack;
import net.minecraft.block.BlockState;
import net.minecraft.entity.SharedMonsterAttributes;
import net.minecraft.entity.ai.attributes.AttributeModifier;
import com.google.common.collect.Multimap;
import net.minecraft.inventory.EquipmentSlotType;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperhoeItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:copperhoe")
    public static final Item block;
    
    public CopperhoeItem(final ModModElements instance) {
        super(instance, 23);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> (Item)new ItemToolCustom() {}.setRegistryName("copperhoe"));
    }
    
    static {
        block = null;
    }
    
    private static class ItemToolCustom extends Item
    {
        protected ItemToolCustom() {
            super(new Item.Properties().func_200916_a(MitemsItemGroup.tab).func_200918_c(100));
        }
        
        public Multimap<String, AttributeModifier> func_111205_h(final EquipmentSlotType equipmentSlot) {
            final Multimap<String, AttributeModifier> multimap = (Multimap<String, AttributeModifier>)super.func_111205_h(equipmentSlot);
            if (equipmentSlot == EquipmentSlotType.MAINHAND) {
                multimap.put((Object)SharedMonsterAttributes.field_111264_e.func_111108_a(), (Object)new AttributeModifier(ItemToolCustom.field_111210_e, "Tool modifier", 2.0, AttributeModifier.Operation.ADDITION));
                multimap.put((Object)SharedMonsterAttributes.field_188790_f.func_111108_a(), (Object)new AttributeModifier(ItemToolCustom.field_185050_h, "Tool modifier", -3.0, AttributeModifier.Operation.ADDITION));
            }
            return multimap;
        }
        
        public boolean func_150897_b(final BlockState state) {
            return 1 >= state.getHarvestLevel();
        }
        
        public float func_150893_a(final ItemStack itemstack, final BlockState blockstate) {
            return 4.0f;
        }
        
        public boolean func_77644_a(final ItemStack stack, final LivingEntity target, final LivingEntity attacker) {
            stack.func_222118_a(1, attacker, i -> i.func_213361_c(EquipmentSlotType.MAINHAND));
            return true;
        }
        
        public boolean func_179218_a(final ItemStack stack, final World worldIn, final BlockState state, final BlockPos pos, final LivingEntity entityLiving) {
            stack.func_222118_a(1, entityLiving, i -> i.func_213361_c(EquipmentSlotType.MAINHAND));
            return true;
        }
        
        public int func_77619_b() {
            return 2;
        }
    }
}
