// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.block.BlockState;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Rarity;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppernuggetItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:coppernugget")
    public static final Item block;
    
    public CoppernuggetItem(final ModModElements instance) {
        super(instance, 45);
    }
    
    @Override
    public void initElements() {
        this.elements.items.add(() -> new ItemCustom());
    }
    
    static {
        block = null;
    }
    
    public static class ItemCustom extends Item
    {
        public ItemCustom() {
            super(new Item.Properties().func_200916_a(MitemsItemGroup.tab).func_200917_a(64).func_208103_a(Rarity.COMMON));
            this.setRegistryName("coppernugget");
        }
        
        public int func_77619_b() {
            return 0;
        }
        
        public int func_77626_a(final ItemStack itemstack) {
            return 0;
        }
        
        public float func_150893_a(final ItemStack par1ItemStack, final BlockState par2Block) {
            return 1.0f;
        }
    }
}
