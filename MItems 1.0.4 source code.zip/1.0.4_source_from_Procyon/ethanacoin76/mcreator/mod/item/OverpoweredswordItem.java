// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.item.SwordItem;
import ethanacoin76.mcreator.mod.itemgroup.MItemsmiscItemGroup;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.IItemTier;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class OverpoweredswordItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:overpoweredsword")
    public static final Item block;
    
    public OverpoweredswordItem(final ModModElements instance) {
        super(instance, 51);
    }
    
    @Override
    public void initElements() {
        final SwordItem swordItem;
        this.elements.items.add(() -> {
            new SwordItem(new IItemTier() {
                public int func_200926_a() {
                    return 100;
                }
                
                public float func_200928_b() {
                    return 4.0f;
                }
                
                public float func_200929_c() {
                    return 998.0f;
                }
                
                public int func_200925_d() {
                    return 1;
                }
                
                public int func_200927_e() {
                    return 2;
                }
                
                public Ingredient func_200924_f() {
                    return Ingredient.field_193370_a;
                }
            }, 3, -3.0f, new Item.Properties().func_200916_a(MItemsmiscItemGroup.tab)) {};
            return (Item)swordItem.setRegistryName("overpoweredsword");
        });
    }
    
    static {
        block = null;
    }
}
