// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.item;

import net.minecraft.item.PickaxeItem;
import ethanacoin76.mcreator.mod.itemgroup.MitemsItemGroup;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.IItemTier;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.item.Item;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperpickaxeItem extends ModModElements.ModElement
{
    @ObjectHolder("mod:copperpickaxe")
    public static final Item block;
    
    public CopperpickaxeItem(final ModModElements instance) {
        super(instance, 12);
    }
    
    @Override
    public void initElements() {
        final PickaxeItem pickaxeItem;
        this.elements.items.add(() -> {
            new PickaxeItem(new IItemTier() {
                public int func_200926_a() {
                    return 100;
                }
                
                public float func_200928_b() {
                    return 4.0f;
                }
                
                public float func_200929_c() {
                    return 2.0f;
                }
                
                public int func_200925_d() {
                    return 1;
                }
                
                public int func_200927_e() {
                    return 2;
                }
                
                public Ingredient func_200924_f() {
                    return Ingredient.field_193370_a;
                }
            }, 1, -3.0f, new Item.Properties().func_200916_a(MitemsItemGroup.tab)) {};
            return (Item)pickaxeItem.setRegistryName("copperpickaxe");
        });
    }
    
    static {
        block = null;
    }
}
