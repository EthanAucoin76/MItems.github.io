// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.enchantment;

import net.minecraft.enchantment.Enchantments;
import net.minecraft.util.DamageSource;
import net.minecraft.enchantment.EnchantmentType;
import net.minecraft.inventory.EquipmentSlotType;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraft.enchantment.Enchantment;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class ArmoryEnchantment extends ModModElements.ModElement
{
    @ObjectHolder("mod:armory")
    public static final Enchantment enchantment;
    
    public ArmoryEnchantment(final ModModElements instance) {
        super(instance, 59);
    }
    
    @Override
    public void initElements() {
        final CustomEnchantment customEnchantment;
        this.elements.enchantments.add(() -> {
            new CustomEnchantment(new EquipmentSlotType[] { EquipmentSlotType.MAINHAND });
            return (Enchantment)customEnchantment.setRegistryName("armory");
        });
    }
    
    static {
        enchantment = null;
    }
    
    public static class CustomEnchantment extends Enchantment
    {
        public CustomEnchantment(final EquipmentSlotType... slots) {
            super(Enchantment.Rarity.VERY_RARE, EnchantmentType.ARMOR, slots);
        }
        
        public int func_77319_d() {
            return 10;
        }
        
        public int func_77325_b() {
            return 1;
        }
        
        public int func_77318_a(final int level, final DamageSource source) {
            return level * 10;
        }
        
        protected boolean func_77326_a(final Enchantment ench) {
            return ench == Enchantments.field_180308_g;
        }
        
        public boolean func_185261_e() {
            return false;
        }
        
        public boolean func_190936_d() {
            return false;
        }
        
        public boolean isAllowedOnBooks() {
            return true;
        }
    }
}
