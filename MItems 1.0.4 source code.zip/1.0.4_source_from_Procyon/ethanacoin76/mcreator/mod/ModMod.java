// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod;

import java.util.function.Predicate;
import net.minecraftforge.fml.network.NetworkRegistry;
import net.minecraft.util.ResourceLocation;
import org.apache.logging.log4j.LogManager;
import net.minecraft.util.SoundEvent;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.entity.EntityType;
import net.minecraft.world.biome.Biome;
import net.minecraft.item.Item;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraftforge.registries.IForgeRegistryEntry;
import net.minecraft.block.Block;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.event.server.FMLServerStartingEvent;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.common.MinecraftForge;
import java.util.function.Consumer;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.fml.network.simple.SimpleChannel;
import org.apache.logging.log4j.Logger;
import net.minecraftforge.fml.common.Mod;

@Mod("mod")
public class ModMod
{
    public static final Logger LOGGER;
    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel PACKET_HANDLER;
    public ModModElements elements;
    
    public ModMod() {
        this.elements = new ModModElements();
        FMLJavaModLoadingContext.get().getModEventBus().addListener((Consumer)this::init);
        FMLJavaModLoadingContext.get().getModEventBus().register((Object)this);
        MinecraftForge.EVENT_BUS.register((Object)this);
    }
    
    private void init(final FMLCommonSetupEvent event) {
        this.elements.getElements().forEach(element -> element.init(event));
    }
    
    @SubscribeEvent
    public void serverLoad(final FMLServerStartingEvent event) {
        this.elements.getElements().forEach(element -> element.serverLoad(event));
    }
    
    @SubscribeEvent
    @OnlyIn(Dist.CLIENT)
    public void clientLoad(final FMLClientSetupEvent event) {
        this.elements.getElements().forEach(element -> element.clientLoad(event));
    }
    
    @SubscribeEvent
    public void registerBlocks(final RegistryEvent.Register<Block> event) {
        event.getRegistry().registerAll((IForgeRegistryEntry[])this.elements.getBlocks().stream().map((Function<? super Object, ?>)Supplier::get).toArray(Block[]::new));
    }
    
    @SubscribeEvent
    public void registerItems(final RegistryEvent.Register<Item> event) {
        event.getRegistry().registerAll((IForgeRegistryEntry[])this.elements.getItems().stream().map((Function<? super Object, ?>)Supplier::get).toArray(Item[]::new));
    }
    
    @SubscribeEvent
    public void registerBiomes(final RegistryEvent.Register<Biome> event) {
        event.getRegistry().registerAll((IForgeRegistryEntry[])this.elements.getBiomes().stream().map((Function<? super Object, ?>)Supplier::get).toArray(Biome[]::new));
    }
    
    @SubscribeEvent
    public void registerEntities(final RegistryEvent.Register<EntityType<?>> event) {
        event.getRegistry().registerAll((IForgeRegistryEntry[])this.elements.getEntities().stream().map((Function<? super Object, ?>)Supplier::get).toArray(EntityType[]::new));
    }
    
    @SubscribeEvent
    public void registerEnchantments(final RegistryEvent.Register<Enchantment> event) {
        event.getRegistry().registerAll((IForgeRegistryEntry[])this.elements.getEnchantments().stream().map((Function<? super Object, ?>)Supplier::get).toArray(Enchantment[]::new));
    }
    
    @SubscribeEvent
    public void registerSounds(final RegistryEvent.Register<SoundEvent> event) {
        this.elements.registerSounds(event);
    }
    
    static {
        LOGGER = LogManager.getLogger((Class)ModMod.class);
        PACKET_HANDLER = NetworkRegistry.newSimpleChannel(new ResourceLocation("mod", "mod"), () -> "1", (Predicate)"1"::equals, (Predicate)"1"::equals);
    }
}
