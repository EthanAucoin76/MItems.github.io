// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.world.dimension;

import java.util.function.LongFunction;
import net.minecraft.world.gen.layer.ZoomLayer;
import net.minecraft.world.gen.area.IAreaFactory;
import net.minecraft.world.gen.area.LazyArea;
import net.minecraft.world.gen.IExtendedNoiseRandom;
import net.minecraft.world.gen.layer.IslandLayer;
import net.minecraft.world.gen.LazyAreaLayerContext;
import java.util.Iterator;
import net.minecraft.world.gen.carver.ICarverConfig;
import net.minecraft.world.gen.carver.WorldCarver;
import net.minecraft.world.gen.carver.CaveWorldCarver;
import net.minecraft.world.gen.feature.ProbabilityConfig;
import net.minecraft.world.gen.GenerationStage;
import java.util.HashSet;
import java.util.Arrays;
import net.minecraft.world.gen.layer.Layer;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.gen.INoiseRandom;
import net.minecraft.world.gen.layer.traits.IC0Transformer;
import net.minecraft.world.gen.OverworldGenSettings;
import net.minecraft.world.gen.OverworldChunkGenerator;
import net.minecraftforge.common.extensions.IForgeDimension;
import net.minecraft.world.biome.provider.BiomeProvider;
import net.minecraft.world.gen.ChunkGenerator;
import net.minecraft.world.dimension.Dimension;
import java.util.function.BiFunction;
import net.minecraft.entity.player.ServerPlayerEntity;
import java.util.function.Function;
import net.minecraft.entity.player.PlayerEntity;
import java.util.Optional;
import net.minecraft.util.math.ChunkPos;
import java.util.Comparator;
import java.util.stream.Collector;
import java.util.stream.Collectors;
import net.minecraft.village.PointOfInterestManager;
import net.minecraft.village.PointOfInterest;
import java.util.List;
import ethanacoin76.mcreator.mod.block.CopperblockBlock;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.MathHelper;
import net.minecraftforge.common.util.ITeleporter;
import net.minecraft.entity.Entity;
import net.minecraft.util.SoundCategory;
import net.minecraft.util.SoundEvent;
import net.minecraft.particles.IParticleData;
import net.minecraft.particles.ParticleTypes;
import net.minecraft.block.Blocks;
import net.minecraft.state.IProperty;
import net.minecraft.util.CachedBlockInfo;
import com.google.common.cache.LoadingCache;
import net.minecraft.world.IWorldReader;
import net.minecraft.block.pattern.BlockPattern;
import javax.annotation.Nullable;
import net.minecraft.util.Direction;
import net.minecraft.world.IWorld;
import net.minecraft.world.World;
import java.util.Random;
import net.minecraft.world.server.ServerWorld;
import net.minecraft.block.BlockState;
import net.minecraft.block.SoundType;
import net.minecraft.block.material.Material;
import net.minecraft.block.NetherPortalBlock;
import net.minecraft.util.math.Vec3i;
import java.lang.reflect.Method;
import net.minecraftforge.registries.IForgeRegistryEntry;
import com.google.common.collect.Sets;
import java.util.Collection;
import com.google.common.collect.ImmutableSet;
import net.minecraftforge.fml.common.ObfuscationReflectionHelper;
import java.util.Set;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.block.Block;
import net.minecraft.client.renderer.RenderTypeLookup;
import net.minecraft.client.renderer.RenderType;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import ethanacoin76.mcreator.mod.item.CopperdimensionItem;
import net.minecraft.item.Item;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraft.network.PacketBuffer;
import net.minecraftforge.common.DimensionManager;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.event.world.RegisterDimensionsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.server.TicketType;
import net.minecraft.village.PointOfInterestType;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.dimension.DimensionType;
import net.minecraftforge.registries.ObjectHolder;
import net.minecraftforge.common.ModDimension;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperdimensionDimension extends ModModElements.ModElement
{
    @ObjectHolder("mod:copperdimension")
    public static final ModDimension dimension;
    @ObjectHolder("mod:copperdimension_portal")
    public static final CustomPortalBlock portal;
    public static DimensionType type;
    private static Biome[] dimensionBiomes;
    private static PointOfInterestType poi;
    public static final TicketType<BlockPos> CUSTOM_PORTAL;
    
    public CopperdimensionDimension(final ModModElements instance) {
        super(instance, 22);
        MinecraftForge.EVENT_BUS.register((Object)this);
        FMLJavaModLoadingContext.get().getModEventBus().register((Object)this);
    }
    
    @SubscribeEvent
    public void registerDimension(final RegistryEvent.Register<ModDimension> event) {
        event.getRegistry().register(new CustomModDimension().setRegistryName("copperdimension"));
    }
    
    @SubscribeEvent
    public void onRegisterDimensionsEvent(final RegisterDimensionsEvent event) {
        if (DimensionType.func_193417_a(new ResourceLocation("mod:copperdimension")) == null) {
            DimensionManager.registerDimension(new ResourceLocation("mod:copperdimension"), CopperdimensionDimension.dimension, (PacketBuffer)null, false);
        }
        CopperdimensionDimension.type = DimensionType.func_193417_a(new ResourceLocation("mod:copperdimension"));
    }
    
    @Override
    public void init(final FMLCommonSetupEvent event) {
        CopperdimensionDimension.dimensionBiomes = new Biome[] { (Biome)ForgeRegistries.BIOMES.getValue(new ResourceLocation("mod:copperbiome")) };
    }
    
    @Override
    public void initElements() {
        this.elements.blocks.add(() -> new CustomPortalBlock());
        this.elements.items.add(() -> (Item)new CopperdimensionItem().setRegistryName("copperdimension"));
    }
    
    @OnlyIn(Dist.CLIENT)
    @Override
    public void clientLoad(final FMLClientSetupEvent event) {
        RenderTypeLookup.setRenderLayer((Block)CopperdimensionDimension.portal, RenderType.func_228645_f_());
    }
    
    @SubscribeEvent
    public void registerPointOfInterest(final RegistryEvent.Register<PointOfInterestType> event) {
        try {
            final Method method = ObfuscationReflectionHelper.findMethod((Class)PointOfInterestType.class, "func_226359_a_", new Class[] { String.class, Set.class, Integer.TYPE, Integer.TYPE });
            method.setAccessible(true);
            CopperdimensionDimension.poi = (PointOfInterestType)method.invoke(null, "copperdimension_portal", Sets.newHashSet((Iterable)ImmutableSet.copyOf((Collection)CopperdimensionDimension.portal.func_176194_O().func_177619_a())), 0, 1);
            event.getRegistry().register((IForgeRegistryEntry)CopperdimensionDimension.poi);
        }
        catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    static {
        dimension = null;
        portal = null;
        CopperdimensionDimension.type = null;
        CopperdimensionDimension.poi = null;
        CUSTOM_PORTAL = TicketType.func_223183_a("copperdimension_portal", Vec3i::compareTo, 300);
    }
    
    public static class CustomPortalBlock extends NetherPortalBlock
    {
        public CustomPortalBlock() {
            super(Block.Properties.func_200945_a(Material.field_151567_E).func_200942_a().func_200944_c().func_200943_b(-1.0f).func_200947_a(SoundType.field_185853_f).func_200951_a(0).func_222380_e());
            this.setRegistryName("copperdimension_portal");
        }
        
        public void func_225534_a_(final BlockState state, final ServerWorld world, final BlockPos pos, final Random random) {
        }
        
        public void portalSpawn(final World world, final BlockPos pos) {
            final Size portalsize = this.isValid((IWorld)world, pos);
            if (portalsize != null) {
                portalsize.placePortalBlocks();
            }
        }
        
        @Nullable
        public Size isValid(final IWorld worldIn, final BlockPos pos) {
            final Size netherportalblock$size = new Size(worldIn, pos, Direction.Axis.X);
            if (netherportalblock$size.isValid() && netherportalblock$size.portalBlockCount == 0) {
                return netherportalblock$size;
            }
            final Size netherportalblock$size2 = new Size(worldIn, pos, Direction.Axis.Z);
            return (netherportalblock$size2.isValid() && netherportalblock$size2.portalBlockCount == 0) ? netherportalblock$size2 : null;
        }
        
        public static BlockPattern.PatternHelper createPatternHelper(final IWorld p_181089_0_, final BlockPos worldIn) {
            Direction.Axis direction$axis = Direction.Axis.Z;
            Size netherportalblock$size = new Size(p_181089_0_, worldIn, Direction.Axis.X);
            final LoadingCache<BlockPos, CachedBlockInfo> loadingcache = (LoadingCache<BlockPos, CachedBlockInfo>)BlockPattern.func_181627_a((IWorldReader)p_181089_0_, true);
            if (!netherportalblock$size.isValid()) {
                direction$axis = Direction.Axis.X;
                netherportalblock$size = new Size(p_181089_0_, worldIn, Direction.Axis.Z);
            }
            if (!netherportalblock$size.isValid()) {
                return new BlockPattern.PatternHelper(worldIn, Direction.NORTH, Direction.UP, (LoadingCache)loadingcache, 1, 1, 1);
            }
            final int[] aint = new int[Direction.AxisDirection.values().length];
            final Direction direction = netherportalblock$size.rightDir.func_176735_f();
            final BlockPos blockpos = netherportalblock$size.bottomLeft.func_177981_b(netherportalblock$size.getHeight() - 1);
            for (final Direction.AxisDirection direction$axisdirection : Direction.AxisDirection.values()) {
                final BlockPattern.PatternHelper blockpattern$patternhelper = new BlockPattern.PatternHelper((direction.func_176743_c() == direction$axisdirection) ? blockpos : blockpos.func_177967_a(netherportalblock$size.rightDir, netherportalblock$size.getWidth() - 1), Direction.func_181076_a(direction$axisdirection, direction$axis), Direction.UP, (LoadingCache)loadingcache, netherportalblock$size.getWidth(), netherportalblock$size.getHeight(), 1);
                for (int i = 0; i < netherportalblock$size.getWidth(); ++i) {
                    for (int j = 0; j < netherportalblock$size.getHeight(); ++j) {
                        final CachedBlockInfo cachedblockinfo = blockpattern$patternhelper.func_177670_a(i, j, 1);
                        if (!cachedblockinfo.func_177509_a().func_196958_f()) {
                            final int[] array = aint;
                            final int ordinal = direction$axisdirection.ordinal();
                            ++array[ordinal];
                        }
                    }
                }
            }
            Direction.AxisDirection direction$axisdirection2 = Direction.AxisDirection.POSITIVE;
            for (final Direction.AxisDirection direction$axisdirection3 : Direction.AxisDirection.values()) {
                if (aint[direction$axisdirection3.ordinal()] < aint[direction$axisdirection2.ordinal()]) {
                    direction$axisdirection2 = direction$axisdirection3;
                }
            }
            return new BlockPattern.PatternHelper((direction.func_176743_c() == direction$axisdirection2) ? blockpos : blockpos.func_177967_a(netherportalblock$size.rightDir, netherportalblock$size.getWidth() - 1), Direction.func_181076_a(direction$axisdirection2, direction$axis), Direction.UP, (LoadingCache)loadingcache, netherportalblock$size.getWidth(), netherportalblock$size.getHeight(), 1);
        }
        
        public BlockState func_196271_a(final BlockState stateIn, final Direction facing, final BlockState facingState, final IWorld worldIn, final BlockPos currentPos, final BlockPos facingPos) {
            final Direction.Axis direction$axis = facing.func_176740_k();
            final Direction.Axis direction$axis2 = (Direction.Axis)stateIn.func_177229_b((IProperty)CustomPortalBlock.field_176550_a);
            final boolean flag = direction$axis2 != direction$axis && direction$axis.func_176722_c();
            return (!flag && facingState.func_177230_c() != this && !new Size(worldIn, currentPos, direction$axis2).func_208508_f()) ? Blocks.field_150350_a.func_176223_P() : super.func_196271_a(stateIn, facing, facingState, worldIn, currentPos, facingPos);
        }
        
        @OnlyIn(Dist.CLIENT)
        public void func_180655_c(final BlockState state, final World world, final BlockPos pos, final Random random) {
            for (int i = 0; i < 4; ++i) {
                double px = pos.func_177958_n() + random.nextFloat();
                final double py = pos.func_177956_o() + random.nextFloat();
                double pz = pos.func_177952_p() + random.nextFloat();
                double vx = (random.nextFloat() - 0.5) / 2.0;
                final double vy = (random.nextFloat() - 0.5) / 2.0;
                double vz = (random.nextFloat() - 0.5) / 2.0;
                final int j = random.nextInt(4) - 1;
                if (world.func_180495_p(pos.func_177976_e()).func_177230_c() != this && world.func_180495_p(pos.func_177974_f()).func_177230_c() != this) {
                    px = pos.func_177958_n() + 0.5 + 0.25 * j;
                    vx = random.nextFloat() * 2.0f * j;
                }
                else {
                    pz = pos.func_177952_p() + 0.5 + 0.25 * j;
                    vz = random.nextFloat() * 2.0f * j;
                }
                world.func_195594_a((IParticleData)ParticleTypes.field_197593_D, px, py, pz, vx, vy, vz);
            }
            if (random.nextInt(110) == 0) {
                world.func_184134_a(pos.func_177958_n() + 0.5, pos.func_177956_o() + 0.5, pos.func_177952_p() + 0.5, (SoundEvent)ForgeRegistries.SOUND_EVENTS.getValue(new ResourceLocation("block.portal.ambient")), SoundCategory.BLOCKS, 0.5f, random.nextFloat() * 0.4f + 0.8f, false);
            }
        }
        
        public void func_196262_a(final BlockState state, final World world, final BlockPos pos, final Entity entity) {
            if (!entity.func_184218_aH() && !entity.func_184207_aI() && entity.func_184222_aU() && !entity.field_70170_p.field_72995_K) {
                if (entity.field_71088_bW > 0) {
                    entity.field_71088_bW = entity.func_82147_ab();
                }
                else if (entity.field_71093_bK != CopperdimensionDimension.type) {
                    entity.field_71088_bW = entity.func_82147_ab();
                    this.teleportToDimension(entity, pos, CopperdimensionDimension.type);
                }
                else {
                    entity.field_71088_bW = entity.func_82147_ab();
                    this.teleportToDimension(entity, pos, DimensionType.field_223227_a_);
                }
            }
        }
        
        private void teleportToDimension(final Entity entity, final BlockPos pos, final DimensionType destinationType) {
            entity.changeDimension(destinationType, (ITeleporter)this.getTeleporterForDimension(entity, pos, entity.func_184102_h().func_71218_a(destinationType)));
        }
        
        private TeleporterDimensionMod getTeleporterForDimension(final Entity entity, final BlockPos pos, final ServerWorld nextWorld) {
            final BlockPattern.PatternHelper bph = createPatternHelper((IWorld)entity.field_70170_p, pos);
            final double d0 = (bph.func_177669_b().func_176740_k() == Direction.Axis.X) ? bph.func_181117_a().func_177952_p() : ((double)bph.func_181117_a().func_177958_n());
            double d2 = (bph.func_177669_b().func_176740_k() == Direction.Axis.X) ? entity.func_226281_cx_() : entity.func_226277_ct_();
            d2 = Math.abs(MathHelper.func_181160_c(d2 - (double)((bph.func_177669_b().func_176746_e().func_176743_c() == Direction.AxisDirection.NEGATIVE) ? 1 : 0), d0, d0 - bph.func_181118_d()));
            final double d3 = MathHelper.func_181160_c(entity.func_226278_cu_() - 1.0, (double)bph.func_181117_a().func_177956_o(), (double)(bph.func_181117_a().func_177956_o() - bph.func_181119_e()));
            return new TeleporterDimensionMod(nextWorld, new Vec3d(d2, d3, 0.0), bph.func_177669_b());
        }
        
        public static class Size
        {
            private final IWorld world;
            private final Direction.Axis axis;
            private final Direction rightDir;
            private final Direction leftDir;
            private int portalBlockCount;
            @Nullable
            private BlockPos bottomLeft;
            private int height;
            private int width;
            
            public Size(final IWorld worldIn, BlockPos pos, final Direction.Axis axisIn) {
                this.world = worldIn;
                this.axis = axisIn;
                if (axisIn == Direction.Axis.X) {
                    this.leftDir = Direction.EAST;
                    this.rightDir = Direction.WEST;
                }
                else {
                    this.leftDir = Direction.NORTH;
                    this.rightDir = Direction.SOUTH;
                }
                for (BlockPos blockpos = pos; pos.func_177956_o() > blockpos.func_177956_o() - 21 && pos.func_177956_o() > 0 && this.func_196900_a(worldIn.func_180495_p(pos.func_177977_b())); pos = pos.func_177977_b()) {}
                final int i = this.getDistanceUntilEdge(pos, this.leftDir) - 1;
                if (i >= 0) {
                    this.bottomLeft = pos.func_177967_a(this.leftDir, i);
                    this.width = this.getDistanceUntilEdge(this.bottomLeft, this.rightDir);
                    if (this.width < 2 || this.width > 21) {
                        this.bottomLeft = null;
                        this.width = 0;
                    }
                }
                if (this.bottomLeft != null) {
                    this.height = this.calculatePortalHeight();
                }
            }
            
            protected int getDistanceUntilEdge(final BlockPos pos, final Direction directionIn) {
                int i;
                for (i = 0; i < 22; ++i) {
                    final BlockPos blockpos = pos.func_177967_a(directionIn, i);
                    if (!this.func_196900_a(this.world.func_180495_p(blockpos))) {
                        break;
                    }
                    if (this.world.func_180495_p(blockpos.func_177977_b()).func_177230_c() != CopperblockBlock.block.func_176223_P().func_177230_c()) {
                        break;
                    }
                }
                final BlockPos framePos = pos.func_177967_a(directionIn, i);
                return (this.world.func_180495_p(framePos).func_177230_c() == CopperblockBlock.block.func_176223_P().func_177230_c()) ? i : 0;
            }
            
            public int getHeight() {
                return this.height;
            }
            
            public int getWidth() {
                return this.width;
            }
            
            protected int calculatePortalHeight() {
                this.height = 0;
            Label_0204:
                while (this.height < 21) {
                    for (int i = 0; i < this.width; ++i) {
                        final BlockPos blockpos = this.bottomLeft.func_177967_a(this.rightDir, i).func_177981_b(this.height);
                        final BlockState blockstate = this.world.func_180495_p(blockpos);
                        if (!this.func_196900_a(blockstate)) {
                            break Label_0204;
                        }
                        final Block block = blockstate.func_177230_c();
                        if (block == CopperdimensionDimension.portal) {
                            ++this.portalBlockCount;
                        }
                        if (i == 0) {
                            final BlockPos framePos = blockpos.func_177972_a(this.leftDir);
                            if (this.world.func_180495_p(framePos).func_177230_c() != CopperblockBlock.block.func_176223_P().func_177230_c()) {
                                break Label_0204;
                            }
                        }
                        else if (i == this.width - 1) {
                            final BlockPos framePos = blockpos.func_177972_a(this.rightDir);
                            if (this.world.func_180495_p(framePos).func_177230_c() != CopperblockBlock.block.func_176223_P().func_177230_c()) {
                                break Label_0204;
                            }
                        }
                    }
                    ++this.height;
                }
                for (int j = 0; j < this.width; ++j) {
                    final BlockPos framePos2 = this.bottomLeft.func_177967_a(this.rightDir, j).func_177981_b(this.height);
                    if (this.world.func_180495_p(framePos2).func_177230_c() != CopperblockBlock.block.func_176223_P().func_177230_c()) {
                        this.height = 0;
                        break;
                    }
                }
                if (this.height <= 21 && this.height >= 3) {
                    return this.height;
                }
                this.bottomLeft = null;
                this.width = 0;
                return this.height = 0;
            }
            
            protected boolean func_196900_a(final BlockState pos) {
                final Block block = pos.func_177230_c();
                return pos.func_196958_f() || block == Blocks.field_150480_ab || block == CopperdimensionDimension.portal;
            }
            
            public boolean isValid() {
                return this.bottomLeft != null && this.width >= 2 && this.width <= 21 && this.height >= 3 && this.height <= 21;
            }
            
            public void placePortalBlocks() {
                for (int i = 0; i < this.width; ++i) {
                    final BlockPos blockpos = this.bottomLeft.func_177967_a(this.rightDir, i);
                    for (int j = 0; j < this.height; ++j) {
                        this.world.func_180501_a(blockpos.func_177981_b(j), (BlockState)CopperdimensionDimension.portal.func_176223_P().func_206870_a((IProperty)NetherPortalBlock.field_176550_a, (Comparable)this.axis), 18);
                    }
                }
            }
            
            private boolean func_196899_f() {
                return this.portalBlockCount >= this.width * this.height;
            }
            
            public boolean func_208508_f() {
                return this.isValid() && this.func_196899_f();
            }
        }
    }
    
    public static class TeleporterDimensionMod implements ITeleporter
    {
        private Vec3d lastPortalVec;
        private Direction teleportDirection;
        protected final ServerWorld world;
        protected final Random random;
        
        public TeleporterDimensionMod(final ServerWorld worldServer, final Vec3d lastPortalVec, final Direction teleportDirection) {
            this.world = worldServer;
            this.random = new Random(worldServer.func_72905_C());
            this.lastPortalVec = lastPortalVec;
            this.teleportDirection = teleportDirection;
        }
        
        @Nullable
        public BlockPattern.PortalInfo placeInExistingPortal(final BlockPos p_222272_1_, final Vec3d p_222272_2_, final Direction directionIn, final double p_222272_4_, final double p_222272_6_, final boolean p_222272_8_) {
            final PointOfInterestManager pointofinterestmanager = this.world.func_217443_B();
            pointofinterestmanager.func_226347_a_((IWorldReader)this.world, p_222272_1_, 128);
            final List<PointOfInterest> list = pointofinterestmanager.func_226353_b_(p_226705_0_ -> p_226705_0_ == CopperdimensionDimension.poi, p_222272_1_, 128, PointOfInterestManager.Status.ANY).collect(Collectors.toList());
            final Optional<PointOfInterest> optional = list.stream().min(Comparator.comparingDouble(p_226706_1_ -> p_226706_1_.func_218261_f().func_177951_i((Vec3i)p_222272_1_)).thenComparingInt(p_226704_0_ -> p_226704_0_.func_218261_f().func_177956_o()));
            final BlockPos blockpos;
            final BlockPattern.PatternHelper blockpattern$patternhelper;
            return optional.map(p_226707_7_ -> {
                blockpos = p_226707_7_.func_218261_f();
                this.world.func_72863_F().func_217228_a((TicketType)CopperdimensionDimension.CUSTOM_PORTAL, new ChunkPos(blockpos), 3, (Object)blockpos);
                blockpattern$patternhelper = CustomPortalBlock.createPatternHelper((IWorld)this.world, blockpos);
                return blockpattern$patternhelper.func_222504_a(directionIn, blockpos, p_222272_6_, p_222272_2_, p_222272_4_);
            }).orElse(null);
        }
        
        public boolean placeInPortal(final Entity p_222268_1_, final float p_222268_2_) {
            final Vec3d vec3d = this.lastPortalVec;
            final Direction direction = this.teleportDirection;
            final BlockPattern.PortalInfo blockpattern$portalinfo = this.placeInExistingPortal(new BlockPos(p_222268_1_), p_222268_1_.func_213322_ci(), direction, vec3d.field_72450_a, vec3d.field_72448_b, p_222268_1_ instanceof PlayerEntity);
            if (blockpattern$portalinfo == null) {
                return false;
            }
            final Vec3d vec3d2 = blockpattern$portalinfo.field_222505_a;
            final Vec3d vec3d3 = blockpattern$portalinfo.field_222506_b;
            p_222268_1_.func_213317_d(vec3d3);
            p_222268_1_.field_70177_z = p_222268_2_ + blockpattern$portalinfo.field_222507_c;
            p_222268_1_.func_225653_b_(vec3d2.field_72450_a, vec3d2.field_72448_b, vec3d2.field_72449_c);
            return true;
        }
        
        public boolean makePortal(final Entity entityIn) {
            final int i = 16;
            double d0 = -1.0;
            final int j = MathHelper.func_76128_c(entityIn.func_226277_ct_());
            final int k = MathHelper.func_76128_c(entityIn.func_226278_cu_());
            final int l = MathHelper.func_76128_c(entityIn.func_226281_cx_());
            int i2 = j;
            int j2 = k;
            int k2 = l;
            int l2 = 0;
            final int i3 = this.random.nextInt(4);
            final BlockPos.Mutable blockpos$mutable = new BlockPos.Mutable();
            for (int j3 = j - 16; j3 <= j + 16; ++j3) {
                final double d2 = j3 + 0.5 - entityIn.func_226277_ct_();
                for (int l3 = l - 16; l3 <= l + 16; ++l3) {
                    final double d3 = l3 + 0.5 - entityIn.func_226281_cx_();
                Label_0460:
                    for (int j4 = this.world.func_72940_L() - 1; j4 >= 0; --j4) {
                        if (this.world.func_175623_d((BlockPos)blockpos$mutable.func_181079_c(j3, j4, l3))) {
                            while (j4 > 0 && this.world.func_175623_d((BlockPos)blockpos$mutable.func_181079_c(j3, j4 - 1, l3))) {
                                --j4;
                            }
                            for (int k3 = i3; k3 < i3 + 4; ++k3) {
                                int l4 = k3 % 2;
                                int i4 = 1 - l4;
                                if (k3 % 4 >= 2) {
                                    l4 = -l4;
                                    i4 = -i4;
                                }
                                for (int j5 = 0; j5 < 3; ++j5) {
                                    for (int k4 = 0; k4 < 4; ++k4) {
                                        for (int l5 = -1; l5 < 4; ++l5) {
                                            final int i5 = j3 + (k4 - 1) * l4 + j5 * i4;
                                            final int j6 = j4 + l5;
                                            final int k5 = l3 + (k4 - 1) * i4 - j5 * l4;
                                            blockpos$mutable.func_181079_c(i5, j6, k5);
                                            if (l5 < 0 && !this.world.func_180495_p((BlockPos)blockpos$mutable).func_185904_a().func_76220_a()) {
                                                continue Label_0460;
                                            }
                                            if (l5 >= 0 && !this.world.func_175623_d((BlockPos)blockpos$mutable)) {
                                                continue Label_0460;
                                            }
                                        }
                                    }
                                }
                                final double d4 = j4 + 0.5 - entityIn.func_226278_cu_();
                                final double d5 = d2 * d2 + d4 * d4 + d3 * d3;
                                if (d0 < 0.0 || d5 < d0) {
                                    d0 = d5;
                                    i2 = j3;
                                    j2 = j4;
                                    k2 = l3;
                                    l2 = k3 % 4;
                                }
                            }
                        }
                    }
                }
            }
            if (d0 < 0.0) {
                for (int l6 = j - 16; l6 <= j + 16; ++l6) {
                    final double d6 = l6 + 0.5 - entityIn.func_226277_ct_();
                    for (int j7 = l - 16; j7 <= l + 16; ++j7) {
                        final double d7 = j7 + 0.5 - entityIn.func_226281_cx_();
                    Label_0831:
                        for (int i6 = this.world.func_72940_L() - 1; i6 >= 0; --i6) {
                            if (this.world.func_175623_d((BlockPos)blockpos$mutable.func_181079_c(l6, i6, j7))) {
                                while (i6 > 0 && this.world.func_175623_d((BlockPos)blockpos$mutable.func_181079_c(l6, i6 - 1, j7))) {
                                    --i6;
                                }
                                for (int l7 = i3; l7 < i3 + 2; ++l7) {
                                    final int l8 = l7 % 2;
                                    final int k6 = 1 - l8;
                                    for (int i7 = 0; i7 < 4; ++i7) {
                                        for (int k7 = -1; k7 < 4; ++k7) {
                                            final int i8 = l6 + (i7 - 1) * l8;
                                            final int j8 = i6 + k7;
                                            final int k8 = j7 + (i7 - 1) * k6;
                                            blockpos$mutable.func_181079_c(i8, j8, k8);
                                            if (k7 < 0 && !this.world.func_180495_p((BlockPos)blockpos$mutable).func_185904_a().func_76220_a()) {
                                                continue Label_0831;
                                            }
                                            if (k7 >= 0 && !this.world.func_175623_d((BlockPos)blockpos$mutable)) {
                                                continue Label_0831;
                                            }
                                        }
                                    }
                                    final double d8 = i6 + 0.5 - entityIn.func_226278_cu_();
                                    final double d9 = d6 * d6 + d8 * d8 + d7 * d7;
                                    if (d0 < 0.0 || d9 < d0) {
                                        d0 = d9;
                                        i2 = l6;
                                        j2 = i6;
                                        k2 = j7;
                                        l2 = l7 % 2;
                                    }
                                }
                            }
                        }
                    }
                }
            }
            final int i9 = i2;
            int k9 = j2;
            final int k10 = k2;
            int l9 = l2 % 2;
            int i10 = 1 - l9;
            if (l2 % 4 >= 2) {
                l9 = -l9;
                i10 = -i10;
            }
            if (d0 < 0.0) {
                j2 = (k9 = MathHelper.func_76125_a(j2, 70, this.world.func_72940_L() - 10));
                for (int j9 = -1; j9 <= 1; ++j9) {
                    for (int i11 = 1; i11 < 3; ++i11) {
                        for (int i12 = -1; i12 < 3; ++i12) {
                            final int l10 = i9 + (i11 - 1) * l9 + j9 * i10;
                            final int j10 = k9 + i12;
                            final int l11 = k10 + (i11 - 1) * i10 - j9 * l9;
                            final boolean flag = i12 < 0;
                            blockpos$mutable.func_181079_c(l10, j10, l11);
                            this.world.func_175656_a((BlockPos)blockpos$mutable, flag ? CopperblockBlock.block.func_176223_P().func_177230_c().func_176223_P() : Blocks.field_150350_a.func_176223_P());
                        }
                    }
                }
            }
            for (int k11 = -1; k11 < 3; ++k11) {
                for (int j11 = -1; j11 < 4; ++j11) {
                    if (k11 == -1 || k11 == 2 || j11 == -1 || j11 == 3) {
                        blockpos$mutable.func_181079_c(i9 + k11 * l9, k9 + j11, k10 + k11 * i10);
                        this.world.func_180501_a((BlockPos)blockpos$mutable, CopperblockBlock.block.func_176223_P().func_177230_c().func_176223_P(), 3);
                    }
                }
            }
            final BlockState blockstate = (BlockState)CopperdimensionDimension.portal.func_176223_P().func_206870_a((IProperty)NetherPortalBlock.field_176550_a, (Comparable)((l9 == 0) ? Direction.Axis.Z : Direction.Axis.X));
            for (int k12 = 0; k12 < 2; ++k12) {
                for (int j12 = 0; j12 < 3; ++j12) {
                    blockpos$mutable.func_181079_c(i9 + k12 * l9, k9 + j12, k10 + k12 * i10);
                    this.world.func_180501_a((BlockPos)blockpos$mutable, blockstate, 18);
                    this.world.func_217443_B().func_219135_a((BlockPos)blockpos$mutable, CopperdimensionDimension.poi);
                }
            }
            return true;
        }
        
        public Entity placeEntity(final Entity entity, final ServerWorld serverworld, final ServerWorld serverworld1, final float yaw, final Function<Boolean, Entity> repositionEntity) {
            final double d0 = entity.func_226277_ct_();
            final double d2 = entity.func_226278_cu_();
            final double d3 = entity.func_226281_cx_();
            if (entity instanceof ServerPlayerEntity) {
                entity.func_70012_b(d0, d2, d3, yaw, entity.field_70125_A);
                if (!this.placeInPortal(entity, yaw)) {
                    this.makePortal(entity);
                    this.placeInPortal(entity, yaw);
                }
                entity.func_70029_a((World)serverworld1);
                serverworld1.func_217447_b((ServerPlayerEntity)entity);
                ((ServerPlayerEntity)entity).field_71135_a.func_147364_a(entity.func_226277_ct_(), entity.func_226278_cu_(), entity.func_226281_cx_(), yaw, entity.field_70125_A);
                return entity;
            }
            Vec3d vec3d = entity.func_213322_ci();
            BlockPos blockpos = new BlockPos(d0, d2, d3);
            final BlockPattern.PortalInfo blockpattern$portalinfo = this.placeInExistingPortal(blockpos, vec3d, this.teleportDirection, this.lastPortalVec.field_72450_a, this.lastPortalVec.field_72448_b, entity instanceof PlayerEntity);
            if (blockpattern$portalinfo == null) {
                return null;
            }
            blockpos = new BlockPos(blockpattern$portalinfo.field_222505_a);
            vec3d = blockpattern$portalinfo.field_222506_b;
            final float f = (float)blockpattern$portalinfo.field_222507_c;
            final Entity entityNew = entity.func_200600_R().func_200721_a((World)serverworld1);
            if (entityNew != null) {
                entityNew.func_180432_n(entity);
                entityNew.func_174828_a(blockpos, entityNew.field_70177_z + f, entityNew.field_70125_A);
                entityNew.func_213317_d(vec3d);
                serverworld1.func_217460_e(entityNew);
            }
            return entityNew;
        }
    }
    
    public static class CustomModDimension extends ModDimension
    {
        public BiFunction<World, DimensionType, ? extends Dimension> getFactory() {
            return CustomDimension::new;
        }
    }
    
    public static class CustomDimension extends Dimension
    {
        private BiomeProviderCustom biomeProviderCustom;
        
        public CustomDimension(final World world, final DimensionType type) {
            super(world, type, 0.5f);
            this.biomeProviderCustom = null;
            this.field_76576_e = false;
        }
        
        @OnlyIn(Dist.CLIENT)
        public Vec3d func_76562_b(final float cangle, final float ticks) {
            return new Vec3d(0.752941176471, 0.847058823529, 1.0);
        }
        
        public ChunkGenerator<?> func_186060_c() {
            if (this.biomeProviderCustom == null) {
                this.biomeProviderCustom = new BiomeProviderCustom(this.field_76579_a);
            }
            return (ChunkGenerator<?>)new ChunkProviderModded((IWorld)this.field_76579_a, this.biomeProviderCustom);
        }
        
        public boolean func_76569_d() {
            return false;
        }
        
        public boolean func_76567_e() {
            return false;
        }
        
        @OnlyIn(Dist.CLIENT)
        public boolean func_76568_b(final int x, final int z) {
            return false;
        }
        
        public IForgeDimension.SleepResult canSleepAt(final PlayerEntity player, final BlockPos pos) {
            return IForgeDimension.SleepResult.ALLOW;
        }
        
        @Nullable
        public BlockPos func_206920_a(final ChunkPos chunkPos, final boolean checkValid) {
            return null;
        }
        
        @Nullable
        public BlockPos func_206921_a(final int x, final int z, final boolean checkValid) {
            return null;
        }
        
        public boolean func_177500_n() {
            return false;
        }
        
        public float func_76563_a(final long worldTime, final float partialTicks) {
            final double d0 = MathHelper.func_181162_h(worldTime / 24000.0 - 0.25);
            final double d2 = 0.5 - Math.cos(d0 * 3.141592653589793) / 2.0;
            return (float)(d0 * 2.0 + d2) / 3.0f;
        }
    }
    
    public static class ChunkProviderModded extends OverworldChunkGenerator
    {
        public ChunkProviderModded(final IWorld world, final BiomeProvider provider) {
            super(world, provider, (OverworldGenSettings)new OverworldGenSettings() {
                public BlockState func_205532_l() {
                    return CopperblockBlock.block.func_176223_P();
                }
                
                public BlockState func_205533_m() {
                    return CopperblockBlock.block.func_176223_P();
                }
            });
            this.field_222558_e.func_202423_a(5349);
        }
        
        public void func_203222_a(final ServerWorld worldIn, final boolean spawnHostileMobs, final boolean spawnPeacefulMobs) {
        }
    }
    
    public static class BiomeLayerCustom implements IC0Transformer
    {
        public int func_202726_a(final INoiseRandom context, final int value) {
            return Registry.field_212624_m.func_148757_b((Object)CopperdimensionDimension.dimensionBiomes[context.func_202696_a(CopperdimensionDimension.dimensionBiomes.length)]);
        }
    }
    
    public static class BiomeProviderCustom extends BiomeProvider
    {
        private Layer genBiomes;
        private static boolean biomesPatched;
        
        public BiomeProviderCustom(final World world) {
            super((Set)new HashSet(Arrays.asList(CopperdimensionDimension.dimensionBiomes)));
            this.genBiomes = this.getBiomeLayer(world.func_72905_C());
            if (!BiomeProviderCustom.biomesPatched) {
                for (final Biome biome : this.field_226837_c_) {
                    biome.func_203609_a(GenerationStage.Carving.AIR, Biome.func_203606_a((WorldCarver)new CaveWorldCarver(ProbabilityConfig::func_214645_a, 256) {
                        {
                            this.field_222718_j = (Set)ImmutableSet.of((Object)CopperblockBlock.block.func_176223_P().func_177230_c(), (Object)biome.func_205401_q().func_215452_a().func_204108_a().func_177230_c(), (Object)biome.func_205401_q().func_215452_a().func_204109_b().func_177230_c());
                        }
                    }, (ICarverConfig)new ProbabilityConfig(0.14285715f)));
                }
                BiomeProviderCustom.biomesPatched = true;
            }
        }
        
        public Biome func_225526_b_(final int x, final int y, final int z) {
            return this.genBiomes.func_215738_a(x, z);
        }
        
        private Layer getBiomeLayer(final long seed) {
            final LongFunction<IExtendedNoiseRandom<LazyArea>> contextFactory = (LongFunction<IExtendedNoiseRandom<LazyArea>>)(l -> new LazyAreaLayerContext(25, seed, l));
            final IAreaFactory<LazyArea> parentLayer = (IAreaFactory<LazyArea>)IslandLayer.INSTANCE.func_202823_a((IExtendedNoiseRandom)contextFactory.apply(1L));
            IAreaFactory<LazyArea> biomeLayer = (IAreaFactory<LazyArea>)new BiomeLayerCustom().func_202713_a((IExtendedNoiseRandom)contextFactory.apply(200L), (IAreaFactory)parentLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1000L), (IAreaFactory)biomeLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1001L), (IAreaFactory)biomeLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1002L), (IAreaFactory)biomeLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1003L), (IAreaFactory)biomeLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1004L), (IAreaFactory)biomeLayer);
            biomeLayer = (IAreaFactory<LazyArea>)ZoomLayer.NORMAL.func_202713_a((IExtendedNoiseRandom)contextFactory.apply(1005L), (IAreaFactory)biomeLayer);
            return new Layer((IAreaFactory)biomeLayer);
        }
        
        static {
            BiomeProviderCustom.biomesPatched = false;
        }
    }
}
