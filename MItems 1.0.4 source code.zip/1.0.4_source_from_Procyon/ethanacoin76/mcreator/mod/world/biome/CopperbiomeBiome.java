// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.world.biome;

import net.minecraft.block.material.Material;
import java.util.Iterator;
import net.minecraft.block.BlockState;
import net.minecraft.block.Block;
import net.minecraft.util.Direction;
import net.minecraft.tags.BlockTags;
import net.minecraft.world.IBlockReader;
import net.minecraft.world.IWorldWriter;
import net.minecraft.world.IWorld;
import net.minecraft.util.math.MutableBoundingBox;
import java.util.Set;
import net.minecraft.util.math.BlockPos;
import java.util.Random;
import net.minecraft.world.gen.IWorldGenerationReader;
import java.util.function.Function;
import net.minecraft.world.gen.feature.AbstractTreeFeature;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.api.distmarker.OnlyIn;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.EntityClassification;
import net.minecraft.world.gen.placement.AtSurfaceWithExtraConfig;
import net.minecraftforge.common.IPlantable;
import net.minecraft.world.gen.blockstateprovider.BlockStateProvider;
import net.minecraft.world.gen.feature.BaseTreeFeatureConfig;
import net.minecraft.world.gen.blockstateprovider.SimpleBlockStateProvider;
import net.minecraft.block.Blocks;
import net.minecraft.world.gen.feature.SeaGrassConfig;
import net.minecraft.world.gen.placement.IPlacementConfig;
import net.minecraft.world.gen.placement.FrequencyConfig;
import net.minecraft.world.gen.placement.Placement;
import net.minecraft.world.gen.feature.IFeatureConfig;
import net.minecraft.world.gen.feature.Feature;
import net.minecraft.world.gen.GenerationStage;
import net.minecraft.world.biome.DefaultBiomeFeatures;
import net.minecraft.world.gen.surfacebuilders.ISurfaceBuilderConfig;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilderConfig;
import ethanacoin76.mcreator.mod.block.CopperoreBlock;
import ethanacoin76.mcreator.mod.block.CopperblockBlock;
import net.minecraft.world.gen.surfacebuilders.SurfaceBuilder;
import net.minecraft.world.biome.Biome;
import net.minecraftforge.common.BiomeManager;
import net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent;
import net.minecraftforge.registries.ObjectHolder;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CopperbiomeBiome extends ModModElements.ModElement
{
    @ObjectHolder("mod:copperbiome")
    public static final CustomBiome biome;
    
    public CopperbiomeBiome(final ModModElements instance) {
        super(instance, 22);
    }
    
    @Override
    public void initElements() {
        this.elements.biomes.add(() -> new CustomBiome());
    }
    
    @Override
    public void init(final FMLCommonSetupEvent event) {
        BiomeManager.addSpawnBiome((Biome)CopperbiomeBiome.biome);
        BiomeManager.addBiome(BiomeManager.BiomeType.COOL, new BiomeManager.BiomeEntry((Biome)CopperbiomeBiome.biome, 10));
    }
    
    static {
        biome = null;
    }
    
    static class CustomBiome extends Biome
    {
        public CustomBiome() {
            super(new Biome.Builder().func_205417_d(0.5f).func_205421_a(0.1f).func_205420_b(0.2f).func_205414_c(0.5f).func_205415_a(Biome.RainType.RAIN).func_205419_a(Biome.Category.NONE).func_205412_a(-10027162).func_205413_b(-16751002).func_222351_a(SurfaceBuilder.field_215396_G, (ISurfaceBuilderConfig)new SurfaceBuilderConfig(CopperblockBlock.block.func_176223_P(), CopperoreBlock.block.func_176223_P(), CopperoreBlock.block.func_176223_P())));
            this.setRegistryName("copperbiome");
            DefaultBiomeFeatures.func_222300_a((Biome)this);
            DefaultBiomeFeatures.func_222335_f((Biome)this);
            DefaultBiomeFeatures.func_222295_c((Biome)this);
            DefaultBiomeFeatures.func_222288_h((Biome)this);
            DefaultBiomeFeatures.func_222300_a((Biome)this);
            this.func_203611_a(GenerationStage.Decoration.VEGETAL_DECORATION, Feature.field_227247_y_.func_225566_b_((IFeatureConfig)DefaultBiomeFeatures.field_226831_z_).func_227228_a_(Placement.field_215017_c.func_227446_a_((IPlacementConfig)new FrequencyConfig(4))));
            this.func_203611_a(GenerationStage.Decoration.VEGETAL_DECORATION, Feature.field_227248_z_.func_225566_b_((IFeatureConfig)DefaultBiomeFeatures.field_226826_u_).func_227228_a_(Placement.field_215018_d.func_227446_a_((IPlacementConfig)new FrequencyConfig(4))));
            this.func_203611_a(GenerationStage.Decoration.VEGETAL_DECORATION, Feature.field_203234_at.func_225566_b_((IFeatureConfig)new SeaGrassConfig(20, 0.3)).func_227228_a_(Placement.field_215036_v.func_227446_a_((IPlacementConfig)IPlacementConfig.field_202468_e)));
            this.func_203611_a(GenerationStage.Decoration.VEGETAL_DECORATION, new CustomTreeFeature().func_225566_b_((IFeatureConfig)new BaseTreeFeatureConfig.Builder((BlockStateProvider)new SimpleBlockStateProvider(Blocks.field_196706_do.func_176223_P()), (BlockStateProvider)new SimpleBlockStateProvider(Blocks.field_196617_K.func_176223_P())).func_225569_d_(7).setSapling((IPlantable)Blocks.field_196678_w).func_225568_b_()).func_227228_a_(Placement.field_215027_m.func_227446_a_((IPlacementConfig)new AtSurfaceWithExtraConfig(3, 0.1f, 1))));
            this.func_201866_a(EntityClassification.MONSTER, new Biome.SpawnListEntry(EntityType.field_200792_f, 20, 4, 4));
        }
        
        @OnlyIn(Dist.CLIENT)
        public int func_225528_a_(final double posX, final double posZ) {
            return -65536;
        }
        
        @OnlyIn(Dist.CLIENT)
        public int func_225527_a_() {
            return -3368704;
        }
        
        @OnlyIn(Dist.CLIENT)
        public int func_225529_c_() {
            return -26368;
        }
    }
    
    static class CustomTreeFeature extends AbstractTreeFeature<BaseTreeFeatureConfig>
    {
        CustomTreeFeature() {
            super((Function)BaseTreeFeatureConfig::func_227376_b_);
        }
        
        protected boolean func_225557_a_(final IWorldGenerationReader worldgen, final Random rand, final BlockPos position, final Set<BlockPos> changedBlocks, final Set<BlockPos> changedBlocks2, final MutableBoundingBox bbox, final BaseTreeFeatureConfig conf) {
            if (!(worldgen instanceof IWorld)) {
                return false;
            }
            final IWorld world = (IWorld)worldgen;
            final int height = rand.nextInt(5) + 7;
            boolean spawnTree = true;
            if (position.func_177956_o() < 1 || position.func_177956_o() + height + 1 > world.func_217301_I()) {
                return false;
            }
            for (int j = position.func_177956_o(); j <= position.func_177956_o() + 1 + height; ++j) {
                int k = 1;
                if (j == position.func_177956_o()) {
                    k = 0;
                }
                if (j >= position.func_177956_o() + height - 1) {
                    k = 2;
                }
                for (int px = position.func_177958_n() - k; px <= position.func_177958_n() + k && spawnTree; ++px) {
                    for (int pz = position.func_177952_p() - k; pz <= position.func_177952_p() + k && spawnTree; ++pz) {
                        if (j >= 0 && j < world.func_217301_I()) {
                            if (!this.isReplaceable(world, new BlockPos(px, j, pz))) {
                                spawnTree = false;
                            }
                        }
                        else {
                            spawnTree = false;
                        }
                    }
                }
            }
            if (!spawnTree) {
                return false;
            }
            final Block ground = world.func_180495_p(position.func_177982_a(0, -1, 0)).func_177230_c();
            final Block ground2 = world.func_180495_p(position.func_177982_a(0, -2, 0)).func_177230_c();
            if ((ground != CopperblockBlock.block.func_176223_P().func_177230_c() && ground != CopperoreBlock.block.func_176223_P().func_177230_c()) || (ground2 != CopperblockBlock.block.func_176223_P().func_177230_c() && ground2 != CopperoreBlock.block.func_176223_P().func_177230_c())) {
                return false;
            }
            BlockState state = world.func_180495_p(position.func_177977_b());
            if (position.func_177956_o() < world.func_217301_I() - height - 1) {
                this.setTreeBlockState(changedBlocks, (IWorldWriter)world, position.func_177977_b(), CopperoreBlock.block.func_176223_P(), bbox);
                for (int genh = position.func_177956_o() - 3 + height; genh <= position.func_177956_o() + height; ++genh) {
                    final int i4 = genh - (position.func_177956_o() + height);
                    for (int j2 = (int)(1.0 - i4 * 0.5), k2 = position.func_177958_n() - j2; k2 <= position.func_177958_n() + j2; ++k2) {
                        for (int i5 = position.func_177952_p() - j2; i5 <= position.func_177952_p() + j2; ++i5) {
                            final int j3 = i5 - position.func_177952_p();
                            if (Math.abs(position.func_177958_n()) != j2 || Math.abs(j3) != j2 || (rand.nextInt(2) != 0 && i4 != 0)) {
                                final BlockPos blockpos = new BlockPos(k2, genh, i5);
                                state = world.func_180495_p(blockpos);
                                if (state.func_177230_c().isAir(state, (IBlockReader)world, blockpos) || state.func_185904_a().func_76230_c() || state.func_203425_a(BlockTags.field_206952_E) || state.func_177230_c() == Blocks.field_196645_X.func_176223_P().func_177230_c() || state.func_177230_c() == Blocks.field_196617_K.func_176223_P().func_177230_c()) {
                                    this.setTreeBlockState(changedBlocks, (IWorldWriter)world, blockpos, Blocks.field_196617_K.func_176223_P(), bbox);
                                }
                            }
                        }
                    }
                }
                for (int genh = 0; genh < height; ++genh) {
                    final BlockPos genhPos = position.func_177981_b(genh);
                    state = world.func_180495_p(genhPos);
                    this.setTreeBlockState(changedBlocks, (IWorldWriter)world, genhPos, Blocks.field_196706_do.func_176223_P(), bbox);
                    if (state.func_177230_c().isAir(state, (IBlockReader)world, genhPos) || state.func_185904_a().func_76230_c() || state.func_203425_a(BlockTags.field_206952_E) || state.func_177230_c() == Blocks.field_196645_X.func_176223_P().func_177230_c() || state.func_177230_c() == Blocks.field_196617_K.func_176223_P().func_177230_c()) {}
                }
                if (rand.nextInt(4) == 0 && height > 5) {
                    for (int hlevel = 0; hlevel < 2; ++hlevel) {
                        for (final Direction Direction : Direction.Plane.HORIZONTAL) {
                            if (rand.nextInt(4 - hlevel) == 0) {
                                final Direction dir = Direction.func_176734_d();
                                this.setTreeBlockState(changedBlocks, (IWorldWriter)world, position.func_177982_a(dir.func_82601_c(), height - 5 + hlevel, dir.func_82599_e()), CopperblockBlock.block.func_176223_P(), bbox);
                            }
                        }
                    }
                }
                return true;
            }
            return false;
        }
        
        private void addVines(final IWorld world, final BlockPos pos, final Set<BlockPos> changedBlocks, final MutableBoundingBox bbox) {
            this.setTreeBlockState(changedBlocks, (IWorldWriter)world, pos, Blocks.field_196645_X.func_176223_P(), bbox);
            int i = 5;
            for (BlockPos blockpos = pos.func_177977_b(); world.func_175623_d(blockpos) && i > 0; blockpos = blockpos.func_177977_b(), --i) {
                this.setTreeBlockState(changedBlocks, (IWorldWriter)world, blockpos, Blocks.field_196645_X.func_176223_P(), bbox);
            }
        }
        
        private boolean canGrowInto(final Block blockType) {
            return blockType.func_176223_P().func_185904_a() == Material.field_151579_a || blockType == Blocks.field_196706_do.func_176223_P().func_177230_c() || blockType == Blocks.field_196617_K.func_176223_P().func_177230_c() || blockType == CopperblockBlock.block.func_176223_P().func_177230_c() || blockType == CopperoreBlock.block.func_176223_P().func_177230_c();
        }
        
        private boolean isReplaceable(final IWorld world, final BlockPos pos) {
            final BlockState state = world.func_180495_p(pos);
            return state.func_177230_c().isAir(state, (IBlockReader)world, pos) || this.canGrowInto(state.func_177230_c()) || !state.func_185904_a().func_76230_c();
        }
        
        private void setTreeBlockState(final Set<BlockPos> changedBlocks, final IWorldWriter world, final BlockPos pos, final BlockState state, final MutableBoundingBox mbb) {
            super.func_227217_a_(world, pos, state, mbb);
            changedBlocks.add(pos.func_185334_h());
        }
    }
}
