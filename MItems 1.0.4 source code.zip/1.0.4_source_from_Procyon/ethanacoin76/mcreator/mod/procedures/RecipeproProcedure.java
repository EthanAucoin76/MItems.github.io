// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.procedures;

import java.util.Map;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class RecipeproProcedure extends ModModElements.ModElement
{
    public RecipeproProcedure(final ModModElements instance) {
        super(instance, 27);
    }
    
    public static void executeProcedure(final Map<String, Object> dependencies) {
    }
}
