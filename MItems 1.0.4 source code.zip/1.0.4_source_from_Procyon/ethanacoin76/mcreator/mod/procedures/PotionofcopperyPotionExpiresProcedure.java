// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.procedures;

import net.minecraft.util.DamageSource;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.Entity;
import java.util.Map;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class PotionofcopperyPotionExpiresProcedure extends ModModElements.ModElement
{
    public PotionofcopperyPotionExpiresProcedure(final ModModElements instance) {
        super(instance, 57);
    }
    
    public static void executeProcedure(final Map<String, Object> dependencies) {
        if (dependencies.get("entity") == null) {
            if (!dependencies.containsKey("entity")) {
                System.err.println("Failed to load dependency entity for procedure PotionofcopperyPotionExpires!");
            }
            return;
        }
        final Entity entity = dependencies.get("entity");
        if (entity instanceof LivingEntity) {
            ((LivingEntity)entity).func_70097_a(new DamageSource("copperkill").func_76348_h(), 5.0f);
        }
    }
}
