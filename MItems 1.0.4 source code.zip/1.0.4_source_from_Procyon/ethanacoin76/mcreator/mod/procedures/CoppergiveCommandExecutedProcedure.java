// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.procedures;

import net.minecraft.entity.item.ExperienceOrbEntity;
import net.minecraft.world.World;
import net.minecraft.entity.Entity;
import net.minecraft.entity.item.ItemEntity;
import net.minecraft.util.IItemProvider;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.world.IWorld;
import java.util.Map;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class CoppergiveCommandExecutedProcedure extends ModModElements.ModElement
{
    public CoppergiveCommandExecutedProcedure(final ModModElements instance) {
        super(instance, 30);
    }
    
    public static void executeProcedure(final Map<String, Object> dependencies) {
        if (dependencies.get("x") == null) {
            if (!dependencies.containsKey("x")) {
                System.err.println("Failed to load dependency x for procedure CoppergiveCommandExecuted!");
            }
            return;
        }
        if (dependencies.get("y") == null) {
            if (!dependencies.containsKey("y")) {
                System.err.println("Failed to load dependency y for procedure CoppergiveCommandExecuted!");
            }
            return;
        }
        if (dependencies.get("z") == null) {
            if (!dependencies.containsKey("z")) {
                System.err.println("Failed to load dependency z for procedure CoppergiveCommandExecuted!");
            }
            return;
        }
        if (dependencies.get("world") == null) {
            if (!dependencies.containsKey("world")) {
                System.err.println("Failed to load dependency world for procedure CoppergiveCommandExecuted!");
            }
            return;
        }
        final double x = (dependencies.get("x") instanceof Integer) ? dependencies.get("x") : dependencies.get("x");
        final double y = (dependencies.get("y") instanceof Integer) ? dependencies.get("y") : dependencies.get("y");
        final double z = (dependencies.get("z") instanceof Integer) ? dependencies.get("z") : dependencies.get("z");
        final IWorld world = dependencies.get("world");
        for (int index0 = 0; index0 < 10; ++index0) {
            if (!world.func_201672_e().field_72995_K) {
                final ItemEntity entityToSpawn = new ItemEntity(world.func_201672_e(), x, y, z, new ItemStack((IItemProvider)Items.field_151045_i, 1));
                entityToSpawn.func_174867_a(10);
                entityToSpawn.func_174873_u();
                world.func_217376_c((Entity)entityToSpawn);
            }
        }
        if (world instanceof World && !world.func_201672_e().field_72995_K) {
            world.func_201672_e().func_217376_c((Entity)new ExperienceOrbEntity(world.func_201672_e(), x, y, z, 100));
        }
    }
}
