// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import java.util.Map;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class DiscordCommandExecutedProcedure extends ModModElements.ModElement
{
    public DiscordCommandExecutedProcedure(final ModModElements instance) {
        super(instance, 55);
    }
    
    public static void executeProcedure(final Map<String, Object> dependencies) {
        final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
        if (mcserv != null) {
            mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("join discord server discord.gg/ethana76"));
        }
    }
}
