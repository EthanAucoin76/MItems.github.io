// 
// Decompiled by Procyon v0.5.36
// 

package ethanacoin76.mcreator.mod.procedures;

import net.minecraft.server.MinecraftServer;
import net.minecraft.util.text.ITextComponent;
import net.minecraft.util.text.StringTextComponent;
import net.minecraftforge.fml.server.ServerLifecycleHooks;
import java.util.Map;
import ethanacoin76.mcreator.mod.ModModElements.ModElement;
import ethanacoin76.mcreator.mod.ModModElements;

@Tag
public class RedditCommandExecutedProcedure extends ModModElements.ModElement
{
    public RedditCommandExecutedProcedure(final ModModElements instance) {
        super(instance, 54);
    }
    
    public static void executeProcedure(final Map<String, Object> dependencies) {
        final MinecraftServer mcserv = ServerLifecycleHooks.getCurrentServer();
        if (mcserv != null) {
            mcserv.func_184103_al().func_148539_a((ITextComponent)new StringTextComponent("join subreddit r/EthanAucoin76"));
        }
    }
}
